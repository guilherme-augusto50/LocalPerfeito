﻿namespace LocalPerfeito
{
    partial class USPrincipal
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox4 = new PictureBox();
            menuStrip = new MenuStrip();
            inícioToolStripMenuItem = new ToolStripMenuItem();
            variedadesToolStripMenuItem = new ToolStripMenuItem();
            favoritosToolStripMenuItem = new ToolStripMenuItem();
            perfilToolStripMenuItem = new ToolStripMenuItem();
            suporteToolStripMenuItem = new ToolStripMenuItem();
            label3 = new Label();
            label1 = new Label();
            FP_usuario = new PictureBox();
            listBoxRestaurantes = new ListBox();
            label2 = new Label();
            btnBuscarLocais = new Button();
            textBox1 = new TextBox();
            panel1 = new Panel();
            panel2 = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            menuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)FP_usuario).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.Transparent;
            pictureBox4.Image = Properties.Resources.logo_localperfeito;
            pictureBox4.Location = new Point(0, 8);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(138, 67);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 12;
            pictureBox4.TabStop = false;
            // 
            // menuStrip
            // 
            menuStrip.Dock = DockStyle.None;
            menuStrip.Items.AddRange(new ToolStripItem[] { inícioToolStripMenuItem, variedadesToolStripMenuItem, favoritosToolStripMenuItem, perfilToolStripMenuItem, suporteToolStripMenuItem });
            menuStrip.LayoutStyle = ToolStripLayoutStyle.VerticalStackWithOverflow;
            menuStrip.Location = new Point(5, 78);
            menuStrip.Name = "menuStrip";
            menuStrip.Padding = new Padding(5, 5, 8, 10);
            menuStrip.RenderMode = ToolStripRenderMode.Professional;
            menuStrip.Size = new Size(106, 392);
            menuStrip.TabIndex = 18;
            // 
            // inícioToolStripMenuItem
            // 
            inícioToolStripMenuItem.Checked = true;
            inícioToolStripMenuItem.CheckState = CheckState.Checked;
            inícioToolStripMenuItem.Image = Properties.Resources.grid_web_7__1_;
            inícioToolStripMenuItem.Name = "inícioToolStripMenuItem";
            inícioToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            inícioToolStripMenuItem.Size = new Size(119, 75);
            inícioToolStripMenuItem.Text = "Início";
            inícioToolStripMenuItem.Click += inícioToolStripMenuItem_Click;
            // 
            // variedadesToolStripMenuItem
            // 
            variedadesToolStripMenuItem.Image = Properties.Resources.store;
            variedadesToolStripMenuItem.Name = "variedadesToolStripMenuItem";
            variedadesToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            variedadesToolStripMenuItem.Size = new Size(119, 75);
            variedadesToolStripMenuItem.Text = "Variedades";
            // 
            // favoritosToolStripMenuItem
            // 
            favoritosToolStripMenuItem.Image = Properties.Resources.star;
            favoritosToolStripMenuItem.Name = "favoritosToolStripMenuItem";
            favoritosToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            favoritosToolStripMenuItem.Size = new Size(119, 75);
            favoritosToolStripMenuItem.Text = "Favoritos";
            // 
            // perfilToolStripMenuItem
            // 
            perfilToolStripMenuItem.Image = Properties.Resources.users_group_alt__1_;
            perfilToolStripMenuItem.Name = "perfilToolStripMenuItem";
            perfilToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            perfilToolStripMenuItem.Size = new Size(119, 75);
            perfilToolStripMenuItem.Text = "Perfil";
            perfilToolStripMenuItem.Click += perfilToolStripMenuItem_Click;
            // 
            // suporteToolStripMenuItem
            // 
            suporteToolStripMenuItem.Image = Properties.Resources.lightbulb;
            suporteToolStripMenuItem.Name = "suporteToolStripMenuItem";
            suporteToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            suporteToolStripMenuItem.Size = new Size(119, 75);
            suporteToolStripMenuItem.Text = "Suporte";
            suporteToolStripMenuItem.Click += suporteToolStripMenuItem_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Impact", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(144, 78);
            label3.Name = "label3";
            label3.Size = new Size(91, 34);
            label3.TabIndex = 20;
            label3.Text = "Locais:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(10, 41);
            label1.Name = "label1";
            label1.Size = new Size(108, 15);
            label1.TabIndex = 19;
            label1.Text = "Locais ao seu redor";
            // 
            // FP_usuario
            // 
            FP_usuario.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            FP_usuario.Image = Properties.Resources.user_icon_vector;
            FP_usuario.Location = new Point(786, 8);
            FP_usuario.Name = "FP_usuario";
            FP_usuario.Size = new Size(50, 50);
            FP_usuario.SizeMode = PictureBoxSizeMode.Zoom;
            FP_usuario.TabIndex = 14;
            FP_usuario.TabStop = false;
            FP_usuario.Click += FP_usuario_Click;
            // 
            // listBoxRestaurantes
            // 
            listBoxRestaurantes.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            listBoxRestaurantes.BackColor = Color.Linen;
            listBoxRestaurantes.FormattingEnabled = true;
            listBoxRestaurantes.HorizontalScrollbar = true;
            listBoxRestaurantes.ItemHeight = 15;
            listBoxRestaurantes.Location = new Point(144, 115);
            listBoxRestaurantes.MultiColumn = true;
            listBoxRestaurantes.Name = "listBoxRestaurantes";
            listBoxRestaurantes.ScrollAlwaysVisible = true;
            listBoxRestaurantes.Size = new Size(655, 319);
            listBoxRestaurantes.TabIndex = 17;
            listBoxRestaurantes.SelectedIndexChanged += listBoxRestaurantes_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Impact", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(10, 18);
            label2.Name = "label2";
            label2.Size = new Size(121, 23);
            label2.TabIndex = 16;
            label2.Text = "RESTAURANTES";
            // 
            // btnBuscarLocais
            // 
            btnBuscarLocais.Location = new Point(681, 90);
            btnBuscarLocais.Name = "btnBuscarLocais";
            btnBuscarLocais.Size = new Size(91, 23);
            btnBuscarLocais.TabIndex = 15;
            btnBuscarLocais.Text = "BuscarLocais";
            btnBuscarLocais.UseVisualStyleBackColor = true;
            btnBuscarLocais.Click += btnBuscarLocais_Click;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Top;
            textBox1.Location = new Point(204, 22);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Pesquisa";
            textBox1.Size = new Size(284, 23);
            textBox1.TabIndex = 13;
            // 
            // panel1
            // 
            panel1.BackColor = Color.LightGray;
            panel1.Controls.Add(menuStrip);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(FP_usuario);
            panel1.Controls.Add(listBoxRestaurantes);
            panel1.Controls.Add(btnBuscarLocais);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(848, 450);
            panel1.TabIndex = 21;
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel2.BackColor = Color.White;
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(textBox1);
            panel2.Location = new Point(144, 8);
            panel2.Name = "panel2";
            panel2.Size = new Size(628, 67);
            panel2.TabIndex = 21;
            // 
            // USPrincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel1);
            Name = "USPrincipal";
            Size = new Size(848, 450);
            Load += USPrincipal_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            menuStrip.ResumeLayout(false);
            menuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)FP_usuario).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox4;
        private MenuStrip menuStrip;
        private ToolStripMenuItem inícioToolStripMenuItem;
        private ToolStripMenuItem variedadesToolStripMenuItem;
        private ToolStripMenuItem favoritosToolStripMenuItem;
        private ToolStripMenuItem perfilToolStripMenuItem;
        private ToolStripMenuItem suporteToolStripMenuItem;
        private Label label3;
        private Label label1;
        private PictureBox FP_usuario;
        private ListBox listBoxRestaurantes;
        private Label label2;
        private Button btnBuscarLocais;
        private TextBox textBox1;
        private Panel panel1;
        private Panel panel2;
    }
}
