﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LocalPerfeito
{
    public partial class USPrincipal : UserControl
    {
        string idusuario;
        private string nomeusuario;
        private string fotoUrl;
        private List<Restaurante> restauranteslist = new List<Restaurante>();

        public string FotoUrl
        {
            get { return fotoUrl; }
            set { fotoUrl = value; }
        }

        public USPrincipal(string fotoUrl, string nomeusuario, string idusuario)
        {
            InitializeComponent();
            this.FotoUrl = fotoUrl;
            this.nomeusuario = nomeusuario;
            this.idusuario = idusuario;
        }

        private async void USPrincipal_Load(object sender, EventArgs e)
        {
            this.Dock = DockStyle.Fill;

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    var imagemBytes = await client.GetByteArrayAsync(FotoUrl);
                    using (var ms = new MemoryStream(imagemBytes))
                    {
                        FP_usuario.Image = Image.FromStream(ms);
                        FP_usuario.SizeMode = PictureBoxSizeMode.Zoom;
                    }
                }
                DeixarFotoRedonda(FP_usuario); // Chama o método para deixar a foto redonda
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao carregar a foto de perfil: " + ex.Message);
            }

            try
            {
                listBoxRestaurantes.Items.Clear(); // Limpa a lista antes de buscar novos locais

                var (latitude, longitude) = await IP_gps.ObterCoordenadas();

                if (latitude == null || longitude == null)
                {
                    MessageBox.Show("Não foi possível obter as coordenadas do seu IP.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                var restaurantes = await FoursquareApi.GetRestaurantsAsync(latitude, longitude); // Cordenadas obtidas do IP
                restauranteslist = restaurantes; // Armazena a lista completa para uso posterior
                //MessageBox.Show($"Foram encontrados {restaurantes.Count} restaurantes.", "Busca Completa", MessageBoxButtons.OK, MessageBoxIcon.Information);

                if (restaurantes.Count == 0)
                {
                    MessageBox.Show("Nenhum restaurante encontrado.", "Busca Completa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                foreach (var restaurante in restaurantes)
                {
                    listBoxRestaurantes.Items.Add(restaurante.Nome);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao buscar locais: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private async void btnBuscarLocais_Click(object sender, EventArgs e)
        {
            try
            {
                listBoxRestaurantes.Items.Clear(); // Limpa a lista antes de buscar novos locais

                var (latitude, longitude) = await IP_gps.ObterCoordenadas();

                if (latitude == null || longitude == null)
                {
                    MessageBox.Show("Não foi possível obter as coordenadas do seu IP.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                var restaurantes = await FoursquareApi.GetRestaurantsAsync(latitude, longitude); // Cordenadas obtidas do IP
                restauranteslist = restaurantes; // Armazena a lista completa para uso posterior
                //MessageBox.Show($"Foram encontrados {restaurantes.Count} restaurantes.", "Busca Completa", MessageBoxButtons.OK, MessageBoxIcon.Information);

                if (restaurantes.Count == 0)
                {
                    MessageBox.Show("Nenhum restaurante encontrado.", "Busca Completa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                foreach (var restaurante in restaurantes)
                {
                    listBoxRestaurantes.Items.Add(restaurante.Nome);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao buscar locais: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void FP_usuario_Click(object sender, EventArgs e)
        {
            try
            {
                panel1.Controls.Clear(); // Limpa o que estiver dentro
                PerfilControl perfil = new PerfilControl(fotoUrl); // Cria a instância do UserControl
                perfil.Dock = DockStyle.Fill; // Faz ocupar todo o espaço

                panel1.Controls.Add(perfil); // Adiciona ao painel
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nao foi possivel abrir o user control do perfil: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void inícioToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void listBoxRestaurantes_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //Restaurante restaurante = new Restaurante();
                if (listBoxRestaurantes.SelectedIndex != -1)
                {
                    var restauranteSelecionado = restauranteslist[listBoxRestaurantes.SelectedIndex];

                    DetalhesRestaurantes detalhesControl = new DetalhesRestaurantes(restauranteSelecionado, Name, idusuario);

                    panel1.Controls.Clear(); // Limpa o que estiver dentro

                    detalhesControl.Dock = DockStyle.Fill; // Faz ocupar todo o espaço

                    panel1.Controls.Add(detalhesControl); // Adiciona ao painel
                }

                else
                {
                    MessageBox.Show("Selecione um restaurante para ver os detalhes.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao exibir detalhes do restaurante: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void perfilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                panel1.Controls.Clear(); // Limpa o que estiver dentro
                PerfilControl perfil = new PerfilControl(fotoUrl); // Cria a instância do UserControl
                perfil.Dock = DockStyle.Fill; // Faz ocupar todo o espaço

                panel1.Controls.Add(perfil); // Adiciona ao painel
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nao foi possivel abrir o user control do perfil: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void DeixarFotoRedonda(PictureBox picBox)
        {
            System.Drawing.Drawing2D.GraphicsPath caminho = new System.Drawing.Drawing2D.GraphicsPath();
            caminho.AddEllipse(0, 0, picBox.Width, picBox.Height);
            picBox.Region = new Region(caminho);
        }

        Restaurante Restaurante = new Restaurante();
        private void suporteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear(); // Limpa o que estiver dentro
            Suporte suporte = new Suporte(nomeusuario, fotoUrl, idusuario); // Cria a instância do UserControl
            perfilToolStripMenuItem.Dock = DockStyle.Fill; // Faz ocupar todo o espaço

            panel1.Controls.Add(suporte); // Adiciona ao painel
        }
    }
}
