﻿namespace LocalPerfeito
{
    partial class DetalhesRestaurantes
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DetalhesRestaurantes));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panelDetalhes = new Panel();
            menuStrip = new MenuStrip();
            inícioToolStripMenuItem = new ToolStripMenuItem();
            variedadesToolStripMenuItem = new ToolStripMenuItem();
            favoritosToolStripMenuItem = new ToolStripMenuItem();
            perfilToolStripMenuItem = new ToolStripMenuItem();
            suporteToolStripMenuItem = new ToolStripMenuItem();
            pictureBox4 = new PictureBox();
            FP_usuario = new PictureBox();
            panel2 = new Panel();
            label2 = new Label();
            label1 = new Label();
            textBox1 = new TextBox();
            guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            guna2ImageRadioButton1 = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            btnAgendar = new Guna.UI2.WinForms.Guna2Button();
            lblContato = new Label();
            txtComentarios = new RichTextBox();
            lblRating = new Label();
            lblCategoria = new Label();
            lblHorario = new Label();
            lblEndereco = new Label();
            lblNome = new Label();
            guna2ImageRadioButton2 = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            guna2ImageRadioButton3 = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            guna2ImageRadioButton4 = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            guna2ImageRadioButton5 = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            panelDetalhes.SuspendLayout();
            menuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)FP_usuario).BeginInit();
            panel2.SuspendLayout();
            guna2Panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panelDetalhes
            // 
            panelDetalhes.Controls.Add(menuStrip);
            panelDetalhes.Controls.Add(pictureBox4);
            panelDetalhes.Controls.Add(FP_usuario);
            panelDetalhes.Controls.Add(panel2);
            panelDetalhes.Controls.Add(guna2Panel1);
            panelDetalhes.Dock = DockStyle.Fill;
            panelDetalhes.Location = new Point(0, 0);
            panelDetalhes.Name = "panelDetalhes";
            panelDetalhes.Size = new Size(848, 450);
            panelDetalhes.TabIndex = 0;
            // 
            // menuStrip
            // 
            menuStrip.BackColor = Color.White;
            menuStrip.Dock = DockStyle.None;
            menuStrip.Items.AddRange(new ToolStripItem[] { inícioToolStripMenuItem, variedadesToolStripMenuItem, favoritosToolStripMenuItem, perfilToolStripMenuItem, suporteToolStripMenuItem });
            menuStrip.LayoutStyle = ToolStripLayoutStyle.VerticalStackWithOverflow;
            menuStrip.Location = new Point(-2, 85);
            menuStrip.Name = "menuStrip";
            menuStrip.Padding = new Padding(5, 5, 8, 10);
            menuStrip.RenderMode = ToolStripRenderMode.Professional;
            menuStrip.Size = new Size(106, 392);
            menuStrip.TabIndex = 26;
            // 
            // inícioToolStripMenuItem
            // 
            inícioToolStripMenuItem.Checked = true;
            inícioToolStripMenuItem.CheckState = CheckState.Checked;
            inícioToolStripMenuItem.Image = Properties.Resources.grid_web_7__1_;
            inícioToolStripMenuItem.Name = "inícioToolStripMenuItem";
            inícioToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            inícioToolStripMenuItem.Size = new Size(92, 75);
            inícioToolStripMenuItem.Text = "Início";
            inícioToolStripMenuItem.Click += inícioToolStripMenuItem_Click;
            // 
            // variedadesToolStripMenuItem
            // 
            variedadesToolStripMenuItem.Image = Properties.Resources.store;
            variedadesToolStripMenuItem.Name = "variedadesToolStripMenuItem";
            variedadesToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            variedadesToolStripMenuItem.Size = new Size(92, 75);
            variedadesToolStripMenuItem.Text = "Variedades";
            // 
            // favoritosToolStripMenuItem
            // 
            favoritosToolStripMenuItem.Image = Properties.Resources.star;
            favoritosToolStripMenuItem.Name = "favoritosToolStripMenuItem";
            favoritosToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            favoritosToolStripMenuItem.Size = new Size(92, 75);
            favoritosToolStripMenuItem.Text = "Favoritos";
            // 
            // perfilToolStripMenuItem
            // 
            perfilToolStripMenuItem.Image = Properties.Resources.users_group_alt__1_;
            perfilToolStripMenuItem.Name = "perfilToolStripMenuItem";
            perfilToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            perfilToolStripMenuItem.Size = new Size(92, 75);
            perfilToolStripMenuItem.Text = "Perfil";
            // 
            // suporteToolStripMenuItem
            // 
            suporteToolStripMenuItem.Image = Properties.Resources.lightbulb;
            suporteToolStripMenuItem.Name = "suporteToolStripMenuItem";
            suporteToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            suporteToolStripMenuItem.Size = new Size(92, 75);
            suporteToolStripMenuItem.Text = "Suporte";
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.Transparent;
            pictureBox4.Image = Properties.Resources.logo_localperfeito;
            pictureBox4.Location = new Point(0, 3);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(138, 67);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 22;
            pictureBox4.TabStop = false;
            // 
            // FP_usuario
            // 
            FP_usuario.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            FP_usuario.Image = Properties.Resources.user_icon_vector;
            FP_usuario.Location = new Point(795, 9);
            FP_usuario.Name = "FP_usuario";
            FP_usuario.Size = new Size(50, 50);
            FP_usuario.SizeMode = PictureBoxSizeMode.Zoom;
            FP_usuario.TabIndex = 23;
            FP_usuario.TabStop = false;
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel2.BackColor = Color.White;
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(textBox1);
            panel2.Location = new Point(137, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(628, 67);
            panel2.TabIndex = 28;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Impact", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(10, 18);
            label2.Name = "label2";
            label2.Size = new Size(121, 23);
            label2.TabIndex = 16;
            label2.Text = "RESTAURANTES";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(10, 41);
            label1.Name = "label1";
            label1.Size = new Size(212, 15);
            label1.TabIndex = 19;
            label1.Text = "Detalhes dos restaurantes selecionados";
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Top;
            textBox1.Location = new Point(278, 22);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Pesquisa";
            textBox1.Size = new Size(284, 23);
            textBox1.TabIndex = 13;
            // 
            // guna2Panel1
            // 
            guna2Panel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            guna2Panel1.BackColor = Color.White;
            guna2Panel1.BorderRadius = 10;
            guna2Panel1.BorderStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            guna2Panel1.Controls.Add(guna2ImageRadioButton5);
            guna2Panel1.Controls.Add(guna2ImageRadioButton4);
            guna2Panel1.Controls.Add(guna2ImageRadioButton3);
            guna2Panel1.Controls.Add(guna2ImageRadioButton2);
            guna2Panel1.Controls.Add(guna2ImageRadioButton1);
            guna2Panel1.Controls.Add(btnAgendar);
            guna2Panel1.Controls.Add(lblContato);
            guna2Panel1.Controls.Add(txtComentarios);
            guna2Panel1.Controls.Add(lblRating);
            guna2Panel1.Controls.Add(lblCategoria);
            guna2Panel1.Controls.Add(lblHorario);
            guna2Panel1.Controls.Add(lblEndereco);
            guna2Panel1.Controls.Add(lblNome);
            guna2Panel1.CustomBorderColor = Color.Red;
            guna2Panel1.CustomizableEdges = customizableEdges8;
            guna2Panel1.Location = new Point(117, 76);
            guna2Panel1.Name = "guna2Panel1";
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges9;
            guna2Panel1.Size = new Size(712, 371);
            guna2Panel1.TabIndex = 37;
            // 
            // guna2ImageRadioButton1
            // 
            guna2ImageRadioButton1.CheckedState.Image = (Image)resources.GetObject("resource.Image4");
            guna2ImageRadioButton1.Image = Properties.Resources.estrela_vazia;
            guna2ImageRadioButton1.ImageOffset = new Point(0, 0);
            guna2ImageRadioButton1.ImageRotate = 0F;
            guna2ImageRadioButton1.Location = new Point(470, 56);
            guna2ImageRadioButton1.Name = "guna2ImageRadioButton1";
            guna2ImageRadioButton1.ShadowDecoration.CustomizableEdges = customizableEdges5;
            guna2ImageRadioButton1.Size = new Size(24, 24);
            guna2ImageRadioButton1.TabIndex = 37;
            // 
            // btnAgendar
            // 
            btnAgendar.CustomizableEdges = customizableEdges6;
            btnAgendar.DisabledState.BorderColor = Color.DarkGray;
            btnAgendar.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAgendar.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAgendar.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAgendar.FillColor = Color.FromArgb(223, 105, 207);
            btnAgendar.Font = new Font("Segoe UI", 9F);
            btnAgendar.ForeColor = Color.White;
            btnAgendar.Location = new Point(20, 309);
            btnAgendar.Name = "btnAgendar";
            btnAgendar.ShadowDecoration.CustomizableEdges = customizableEdges7;
            btnAgendar.Size = new Size(165, 36);
            btnAgendar.TabIndex = 35;
            btnAgendar.Text = "Agendar";
            btnAgendar.Click += btnAgendar_Click;
            // 
            // lblContato
            // 
            lblContato.AutoSize = true;
            lblContato.Location = new Point(42, 146);
            lblContato.Name = "lblContato";
            lblContato.Size = new Size(50, 15);
            lblContato.TabIndex = 36;
            lblContato.Text = "Contato";
            // 
            // txtComentarios
            // 
            txtComentarios.BackColor = Color.Gainsboro;
            txtComentarios.Location = new Point(396, 86);
            txtComentarios.Name = "txtComentarios";
            txtComentarios.Size = new Size(263, 160);
            txtComentarios.TabIndex = 34;
            txtComentarios.Text = "";
            // 
            // lblRating
            // 
            lblRating.AutoSize = true;
            lblRating.Location = new Point(414, 62);
            lblRating.Name = "lblRating";
            lblRating.Size = new Size(41, 15);
            lblRating.TabIndex = 32;
            lblRating.Text = "Rating";
            // 
            // lblCategoria
            // 
            lblCategoria.AutoSize = true;
            lblCategoria.Location = new Point(42, 104);
            lblCategoria.Name = "lblCategoria";
            lblCategoria.Size = new Size(58, 15);
            lblCategoria.TabIndex = 33;
            lblCategoria.Text = "Categoria";
            // 
            // lblHorario
            // 
            lblHorario.AutoSize = true;
            lblHorario.Location = new Point(45, 186);
            lblHorario.Name = "lblHorario";
            lblHorario.Size = new Size(47, 15);
            lblHorario.TabIndex = 31;
            lblHorario.Text = "Horario";
            // 
            // lblEndereco
            // 
            lblEndereco.AutoSize = true;
            lblEndereco.Location = new Point(42, 71);
            lblEndereco.Name = "lblEndereco";
            lblEndereco.Size = new Size(56, 15);
            lblEndereco.TabIndex = 30;
            lblEndereco.Text = "Endereco";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblNome.Location = new Point(42, 15);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(86, 31);
            lblNome.TabIndex = 29;
            lblNome.Text = "Nome";
            // 
            // guna2ImageRadioButton2
            // 
            guna2ImageRadioButton2.CheckedState.Image = (Image)resources.GetObject("resource.Image3");
            guna2ImageRadioButton2.Image = Properties.Resources.estrela_vazia;
            guna2ImageRadioButton2.ImageOffset = new Point(0, 0);
            guna2ImageRadioButton2.ImageRotate = 0F;
            guna2ImageRadioButton2.Location = new Point(500, 56);
            guna2ImageRadioButton2.Name = "guna2ImageRadioButton2";
            guna2ImageRadioButton2.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2ImageRadioButton2.Size = new Size(24, 24);
            guna2ImageRadioButton2.TabIndex = 38;
            // 
            // guna2ImageRadioButton3
            // 
            guna2ImageRadioButton3.CheckedState.Image = (Image)resources.GetObject("resource.Image2");
            guna2ImageRadioButton3.Image = Properties.Resources.estrela_vazia;
            guna2ImageRadioButton3.ImageOffset = new Point(0, 0);
            guna2ImageRadioButton3.ImageRotate = 0F;
            guna2ImageRadioButton3.Location = new Point(530, 56);
            guna2ImageRadioButton3.Name = "guna2ImageRadioButton3";
            guna2ImageRadioButton3.ShadowDecoration.CustomizableEdges = customizableEdges3;
            guna2ImageRadioButton3.Size = new Size(24, 24);
            guna2ImageRadioButton3.TabIndex = 39;
            // 
            // guna2ImageRadioButton4
            // 
            guna2ImageRadioButton4.CheckedState.Image = (Image)resources.GetObject("resource.Image1");
            guna2ImageRadioButton4.Image = Properties.Resources.estrela_vazia;
            guna2ImageRadioButton4.ImageOffset = new Point(0, 0);
            guna2ImageRadioButton4.ImageRotate = 0F;
            guna2ImageRadioButton4.Location = new Point(560, 56);
            guna2ImageRadioButton4.Name = "guna2ImageRadioButton4";
            guna2ImageRadioButton4.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2ImageRadioButton4.Size = new Size(24, 24);
            guna2ImageRadioButton4.TabIndex = 40;
            // 
            // guna2ImageRadioButton5
            // 
            guna2ImageRadioButton5.CheckedState.Image = (Image)resources.GetObject("resource.Image");
            guna2ImageRadioButton5.Image = Properties.Resources.estrela_vazia;
            guna2ImageRadioButton5.ImageOffset = new Point(0, 0);
            guna2ImageRadioButton5.ImageRotate = 0F;
            guna2ImageRadioButton5.Location = new Point(590, 56);
            guna2ImageRadioButton5.Name = "guna2ImageRadioButton5";
            guna2ImageRadioButton5.ShadowDecoration.CustomizableEdges = customizableEdges1;
            guna2ImageRadioButton5.Size = new Size(24, 24);
            guna2ImageRadioButton5.TabIndex = 41;
            // 
            // DetalhesRestaurantes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panelDetalhes);
            Name = "DetalhesRestaurantes";
            Size = new Size(848, 450);
            panelDetalhes.ResumeLayout(false);
            panelDetalhes.PerformLayout();
            menuStrip.ResumeLayout(false);
            menuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)FP_usuario).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            guna2Panel1.ResumeLayout(false);
            guna2Panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelDetalhes;
        private MenuStrip menuStrip;
        private ToolStripMenuItem inícioToolStripMenuItem;
        private ToolStripMenuItem variedadesToolStripMenuItem;
        private ToolStripMenuItem favoritosToolStripMenuItem;
        private ToolStripMenuItem perfilToolStripMenuItem;
        private ToolStripMenuItem suporteToolStripMenuItem;
        private PictureBox pictureBox4;
        private PictureBox FP_usuario;
        private Panel panel2;
        private Label label2;
        private Label label1;
        private TextBox textBox1;
        private Guna.UI2.WinForms.Guna2Button btnAgendar;
        private RichTextBox txtComentarios;
        private Label lblCategoria;
        private Label lblRating;
        private Label lblHorario;
        private Label lblEndereco;
        private Label lblNome;
        private Label lblContato;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2ImageRadioButton guna2ImageRadioButton1;
        private Guna.UI2.WinForms.Guna2ImageRadioButton guna2ImageRadioButton5;
        private Guna.UI2.WinForms.Guna2ImageRadioButton guna2ImageRadioButton4;
        private Guna.UI2.WinForms.Guna2ImageRadioButton guna2ImageRadioButton3;
        private Guna.UI2.WinForms.Guna2ImageRadioButton guna2ImageRadioButton2;
    }
}
