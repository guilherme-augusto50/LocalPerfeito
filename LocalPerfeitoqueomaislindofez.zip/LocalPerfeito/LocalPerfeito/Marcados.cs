﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocalPerfeito
{
    public class Marcados
    {
       private int idusuario;
       private int idlcal = -1;
       private string nome;
       private string endereco;
       private string descricao;

        public int IdUsuario
        {
            get { return idusuario; }
            set { idusuario = value; }
        }
        public int IdLocal
        {
            get { return idlcal; }
            set { idlcal = value; }
        }
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        public string Endereco
        {
            get { return endereco; }
            set { endereco = value; }
        }
        public string Descricao
        {
            get { return descricao; }
            set { descricao = value; }
        }

        public int MarcarLocalSeNaoExistir(string nome, string descricao, string endereco)
        {
            int idlocal = -1;

            using (MySqlConnection conexao = new ConexaoDb().Conectar())
            {
                conexao.Open();

                // Verifica se o local já existe no banco de dados
                string selecionarQuery = "SELECT Id_local FROM Locais WHERE nome = @nome AND edereco = @endereco";
                using (MySqlCommand selectComand = new MySqlCommand(selecionarQuery, conexao))
                {
                    selectComand.Parameters.AddWithValue("@nome", nome);
                    selectComand.Parameters.AddWithValue("@endereco", endereco);
                    object resultado = selectComand.ExecuteScalar();

                    if (resultado != null)
                    {
                        idlocal = Convert.ToInt32(resultado);
                    }
                    else
                    {
                        string inserirQuery = "INSERT INTO Locais (nome, descricao, edereco) VALUES (@nome, @desc, @endereco)";
                        using (MySqlCommand insertcmd = new MySqlCommand(inserirQuery, conexao))
                        {
                            insertcmd.Parameters.AddWithValue("@nome", nome);
                            insertcmd.Parameters.AddWithValue("@desc", descricao);
                            insertcmd.Parameters.AddWithValue("@endereco", endereco);
                            insertcmd.ExecuteNonQuery();
                            idlocal = (int)insertcmd.LastInsertedId;
                        }
                    }
                }
            }
            return idlocal;
        }

        public void MarcarLocal(int idusuario, int idlocal)
        {
            using (MySqlConnection conexao = new ConexaoDb().Conectar())
            {
                conexao.Open();
                string query = "INSERT INTO Marcados (id_usuario, id_local) VALUES (@idusuario, @idlocal)";
                using (MySqlCommand cmd = new MySqlCommand(query, conexao))
                {
                    cmd.Parameters.AddWithValue("@idusuario", idusuario);
                    cmd.Parameters.AddWithValue("@idlocal", idlocal);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
