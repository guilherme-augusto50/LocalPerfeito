﻿namespace LocalPerfeito
{
    partial class cadastroempresa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            guna2Separator5 = new Guna.UI2.WinForms.Guna2Separator();
            txtcnpj = new Guna.UI2.WinForms.Guna2TextBox();
            label1 = new Label();
            guna2Separator3 = new Guna.UI2.WinForms.Guna2Separator();
            guna2Separator2 = new Guna.UI2.WinForms.Guna2Separator();
            guna2Separator1 = new Guna.UI2.WinForms.Guna2Separator();
            txtNome = new Guna.UI2.WinForms.Guna2TextBox();
            linkLabel1 = new LinkLabel();
            txtEmail = new Guna.UI2.WinForms.Guna2TextBox();
            label4 = new Label();
            txtSenha = new Guna.UI2.WinForms.Guna2TextBox();
            btncadastrese = new Guna.UI2.WinForms.Guna2Button();
            pictureBox1 = new PictureBox();
            guna2ShadowPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // guna2ShadowPanel1
            // 
            guna2ShadowPanel1.BackColor = Color.Transparent;
            guna2ShadowPanel1.Controls.Add(guna2Separator5);
            guna2ShadowPanel1.Controls.Add(txtcnpj);
            guna2ShadowPanel1.Controls.Add(label1);
            guna2ShadowPanel1.Controls.Add(guna2Separator3);
            guna2ShadowPanel1.Controls.Add(guna2Separator2);
            guna2ShadowPanel1.Controls.Add(guna2Separator1);
            guna2ShadowPanel1.Controls.Add(txtNome);
            guna2ShadowPanel1.Controls.Add(linkLabel1);
            guna2ShadowPanel1.Controls.Add(txtEmail);
            guna2ShadowPanel1.Controls.Add(label4);
            guna2ShadowPanel1.Controls.Add(txtSenha);
            guna2ShadowPanel1.Controls.Add(btncadastrese);
            guna2ShadowPanel1.FillColor = Color.White;
            guna2ShadowPanel1.Location = new Point(246, 113);
            guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            guna2ShadowPanel1.Radius = 6;
            guna2ShadowPanel1.ShadowColor = Color.Black;
            guna2ShadowPanel1.Size = new Size(308, 325);
            guna2ShadowPanel1.TabIndex = 14;
            // 
            // guna2Separator5
            // 
            guna2Separator5.Location = new Point(28, 193);
            guna2Separator5.Name = "guna2Separator5";
            guna2Separator5.Size = new Size(247, 10);
            guna2Separator5.TabIndex = 16;
            // 
            // txtcnpj
            // 
            txtcnpj.Cursor = Cursors.IBeam;
            txtcnpj.CustomizableEdges = customizableEdges11;
            txtcnpj.DefaultText = "";
            txtcnpj.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtcnpj.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtcnpj.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtcnpj.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtcnpj.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtcnpj.Font = new Font("Segoe UI", 9F);
            txtcnpj.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtcnpj.Location = new Point(28, 209);
            txtcnpj.Name = "txtcnpj";
            txtcnpj.PlaceholderForeColor = Color.FromArgb(198, 200, 217);
            txtcnpj.PlaceholderText = "CNPJ";
            txtcnpj.SelectedText = "";
            txtcnpj.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtcnpj.Size = new Size(247, 23);
            txtcnpj.TabIndex = 15;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft YaHei UI", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Gray;
            label1.Location = new Point(12, 19);
            label1.Name = "label1";
            label1.Size = new Size(284, 26);
            label1.TabIndex = 14;
            label1.Text = "Criar uma conta empresarial";
            // 
            // guna2Separator3
            // 
            guna2Separator3.Location = new Point(28, 238);
            guna2Separator3.Name = "guna2Separator3";
            guna2Separator3.Size = new Size(247, 10);
            guna2Separator3.TabIndex = 12;
            // 
            // guna2Separator2
            // 
            guna2Separator2.Location = new Point(28, 148);
            guna2Separator2.Name = "guna2Separator2";
            guna2Separator2.Size = new Size(247, 10);
            guna2Separator2.TabIndex = 11;
            // 
            // guna2Separator1
            // 
            guna2Separator1.Location = new Point(28, 103);
            guna2Separator1.Name = "guna2Separator1";
            guna2Separator1.Size = new Size(247, 10);
            guna2Separator1.TabIndex = 10;
            // 
            // txtNome
            // 
            txtNome.Cursor = Cursors.IBeam;
            txtNome.CustomizableEdges = customizableEdges13;
            txtNome.DefaultText = "";
            txtNome.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtNome.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtNome.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtNome.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtNome.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNome.Font = new Font("Segoe UI", 9F);
            txtNome.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNome.Location = new Point(28, 74);
            txtNome.Name = "txtNome";
            txtNome.PlaceholderText = "Nome";
            txtNome.SelectedText = "";
            txtNome.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtNome.Size = new Size(247, 23);
            txtNome.TabIndex = 1;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Cursor = Cursors.Hand;
            linkLabel1.LinkColor = Color.FromArgb(255, 128, 255);
            linkLabel1.Location = new Point(166, 295);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(57, 15);
            linkLabel1.TabIndex = 5;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Faz Login";
            // 
            // txtEmail
            // 
            txtEmail.Cursor = Cursors.IBeam;
            txtEmail.CustomizableEdges = customizableEdges15;
            txtEmail.DefaultText = "";
            txtEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Font = new Font("Segoe UI", 9F);
            txtEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Location = new Point(28, 119);
            txtEmail.Name = "txtEmail";
            txtEmail.PlaceholderText = "Email";
            txtEmail.SelectedText = "";
            txtEmail.ShadowDecoration.CustomizableEdges = customizableEdges16;
            txtEmail.Size = new Size(247, 23);
            txtEmail.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(51, 295);
            label4.Name = "label4";
            label4.Size = new Size(109, 15);
            label4.TabIndex = 8;
            label4.Text = "Já tem uma conta ?";
            // 
            // txtSenha
            // 
            txtSenha.Cursor = Cursors.IBeam;
            txtSenha.CustomizableEdges = customizableEdges17;
            txtSenha.DefaultText = "";
            txtSenha.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtSenha.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtSenha.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtSenha.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtSenha.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSenha.Font = new Font("Segoe UI", 9F);
            txtSenha.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSenha.Location = new Point(28, 164);
            txtSenha.Name = "txtSenha";
            txtSenha.PlaceholderForeColor = Color.FromArgb(198, 200, 217);
            txtSenha.PlaceholderText = "Senha";
            txtSenha.SelectedText = "";
            txtSenha.ShadowDecoration.CustomizableEdges = customizableEdges18;
            txtSenha.Size = new Size(247, 23);
            txtSenha.TabIndex = 3;
            // 
            // btncadastrese
            // 
            btncadastrese.BorderRadius = 6;
            btncadastrese.Cursor = Cursors.Hand;
            btncadastrese.CustomizableEdges = customizableEdges19;
            btncadastrese.DisabledState.BorderColor = Color.DarkGray;
            btncadastrese.DisabledState.CustomBorderColor = Color.DarkGray;
            btncadastrese.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btncadastrese.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btncadastrese.FillColor = Color.FromArgb(255, 128, 255);
            btncadastrese.Font = new Font("Segoe UI", 9F);
            btncadastrese.ForeColor = Color.White;
            btncadastrese.Location = new Point(51, 254);
            btncadastrese.Name = "btncadastrese";
            btncadastrese.ShadowDecoration.CustomizableEdges = customizableEdges20;
            btncadastrese.Size = new Size(203, 30);
            btncadastrese.TabIndex = 4;
            btncadastrese.Text = "Cadastra-se";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.logo_localperfeito;
            pictureBox1.Location = new Point(283, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(238, 95);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 13;
            pictureBox1.TabStop = false;
            // 
            // cadastroempresa
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(211, 193, 252);
            ClientSize = new Size(800, 450);
            Controls.Add(guna2ShadowPanel1);
            Controls.Add(pictureBox1);
            Name = "cadastroempresa";
            Text = "Form1";
            guna2ShadowPanel1.ResumeLayout(false);
            guna2ShadowPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator5;
        private Guna.UI2.WinForms.Guna2TextBox txtcnpj;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator3;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator2;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator1;
        private Guna.UI2.WinForms.Guna2TextBox txtNome;
        private LinkLabel linkLabel1;
        private Guna.UI2.WinForms.Guna2TextBox txtEmail;
        private Label label4;
        private Guna.UI2.WinForms.Guna2TextBox txtSenha;
        private Guna.UI2.WinForms.Guna2Button btncadastrese;
        private PictureBox pictureBox1;
    }
}