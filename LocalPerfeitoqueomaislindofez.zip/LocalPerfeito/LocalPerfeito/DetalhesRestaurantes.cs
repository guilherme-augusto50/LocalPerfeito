﻿using MySqlX.XDevAPI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LocalPerfeito
{
    public partial class DetalhesRestaurantes : UserControl
    {
        private string fotoUrl;
        private string nome;
        private string Idusuario;
        private Restaurante restaurante;
        public DetalhesRestaurantes(Restaurante restauranteSelecionado, string nome, string idusuario)
        {
            InitializeComponent();
            this.restaurante = restauranteSelecionado;
            ExibirInformaçoes();
            this.nome = nome;
            Idusuario = idusuario;
        }
        private void ExibirInformaçoes()
        {
            lblNome.Text = restaurante.Nome;
            lblEndereco.Text = "Endereço:" + restaurante.Endereco;
            lblContato.Text = "Contato: " + restaurante.Contato;
            lblCategoria.Text = "Categoria: " + restaurante.Categoria;
            lblRating.Text = restaurante.Avaliacao + "estrelas";


        }

        private void btnAgendar_Click(object sender, EventArgs e)
        {
            try {
                Marcados marcado = new Marcados();

                string nome = restaurante.Nome;
                string descricao = restaurante.Descricao;
                string endereco = restaurante.Endereco;

                    int idlocal = marcado.MarcarLocalSeNaoExistir(nome, descricao, endereco);

                
                MessageBox.Show("Local agendado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao agendar: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void inícioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panelDetalhes.Controls.Clear();
            telaprincipal principal = new telaprincipal(fotoUrl,nome, Idusuario);
            principal.Dock = DockStyle.Fill;

            panelDetalhes.Controls.Add(principal);
        }
    }
}
