﻿namespace LocalPerfeito
{
    partial class Endereço
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            txtEndereco = new TextBox();
            label1 = new Label();
            btnSalvar = new Guna.UI2.WinForms.Guna2Button();
            SuspendLayout();
            // 
            // txtEndereco
            // 
            txtEndereco.Location = new Point(12, 70);
            txtEndereco.Name = "txtEndereco";
            txtEndereco.PlaceholderText = "Seu Endereço";
            txtEndereco.Size = new Size(434, 21);
            txtEndereco.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(422, 45);
            label1.TabIndex = 1;
            label1.Text = "🔒 Seus dados estão protegidos:\nEste endereço será utilizado apenas para sugerir locais próximos a você.\nNenhuma informação será compartilhada com terceiros, conforme a LGPD.";
            // 
            // btnSalvar
            // 
            btnSalvar.BackColor = Color.Transparent;
            btnSalvar.BorderRadius = 6;
            btnSalvar.Cursor = Cursors.Hand;
            btnSalvar.CustomizableEdges = customizableEdges3;
            btnSalvar.DisabledState.BorderColor = Color.DarkGray;
            btnSalvar.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSalvar.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSalvar.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSalvar.FillColor = Color.FromArgb(223, 105, 207);
            btnSalvar.Font = new Font("Segoe UI", 9F);
            btnSalvar.ForeColor = Color.White;
            btnSalvar.Location = new Point(166, 116);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.ShadowDecoration.Color = Color.FromArgb(255, 128, 128);
            btnSalvar.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnSalvar.ShadowDecoration.Enabled = true;
            btnSalvar.Size = new Size(138, 30);
            btnSalvar.TabIndex = 2;
            btnSalvar.Text = "Salvar";
            btnSalvar.Click += guna2Button1_Click;
            // 
            // Endereço
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(458, 175);
            Controls.Add(btnSalvar);
            Controls.Add(label1);
            Controls.Add(txtEndereco);
            Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Margin = new Padding(4, 3, 4, 3);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Endereço";
            ShowIcon = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            Text = "Endereço";
            TopMost = true;
            Load += Endereço_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtEndereco;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Button btnSalvar;
    }
}