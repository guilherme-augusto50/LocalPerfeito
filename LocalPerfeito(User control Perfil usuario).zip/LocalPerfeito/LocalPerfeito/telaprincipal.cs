﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LocalPerfeito
{
    public partial class telaprincipal : Form
    {
        public telaprincipal()
        {
            InitializeComponent();
        }
        private void telaprincipal_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void telaprincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button6_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private async void telaprincipal_Load_1(object sender, EventArgs e)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    var imagemBytes = await client.GetByteArrayAsync(fotoUrl);
                    using (var ms = new MemoryStream(imagemBytes))
                    {
                        FP_usuario.Image = Image.FromStream(ms);
                        FP_usuario.SizeMode = PictureBoxSizeMode.Zoom;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar a foto de perfil: " + ex.Message);
            }
        }


        private void flowRestaurantes_Paint(object sender, PaintEventArgs e)
        {

        }

        private void toolStripContainer2_TopToolStripPanel_Click(object sender, EventArgs e)
        {

        }

        private void BtnInicio_Click(object sender, EventArgs e)
        {

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private async void btnBuscarLocais_Click(object sender, EventArgs e)
        {
            try
            {
                listBoxRestaurantes.Items.Clear(); // Limpa a lista antes de buscar novos locais

                var (latitude, longitude) = await IP_gps.ObterCoordenadas();

                if (latitude == null || longitude == null)
                {
                    MessageBox.Show("Não foi possível obter as coordenadas do seu IP.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                var restaurantes = await FoursquareApi.GetRestaurantsAsync(latitude, longitude); // Cordenadas obtidas do IP
                MessageBox.Show($"Foram encontrados {restaurantes.Count} restaurantes.", "Busca Completa", MessageBoxButtons.OK, MessageBoxIcon.Information);

                if (restaurantes.Count == 0)
                {
                    MessageBox.Show("Nenhum restaurante encontrado.", "Busca Completa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                foreach (var restaurante in restaurantes)
                {
                    listBoxRestaurantes.Items.Add(restaurante.Nome);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao buscar locais: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void guna2ContextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }



        private void guna2HtmlToolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void FP_usuario_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear(); // Limpa o que estiver dentro
            PerfilControl perfil = new PerfilControl(); // Cria a instância do UserControl
            perfil.Dock = DockStyle.Fill; // Faz ocupar todo o espaço
            panel1.Controls.Add(perfil); // Adiciona ao painel
        }

        private string fotoUrl;

        public telaprincipal(string fotoUrl)
        {
            InitializeComponent();
            this.fotoUrl = fotoUrl;
        }

        private void perfilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear(); // Limpa o que estiver dentro
            PerfilControl perfil = new PerfilControl(); // Cria a instância do UserControl
            perfil.Dock = DockStyle.Fill; // Faz ocupar todo o espaço
            panel1.Controls.Add(perfil); // Adiciona ao painel
        }

        private void toolStripContainer1_ContentPanel_Load(object sender, EventArgs e)
        {

        }
    }
}
