﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;

namespace LocalPerfeito
{
    public class FoursquareApi
    {
        private static readonly string apiKey = "X5OJWKQMWAZ5UHNVENY0PJTR1N2J2OF5JXJYDJTETJWDRDYA";
        private static readonly string searchEndpoint = "https://places-api.foursquare.com/places/search";
        private static readonly string detailsEndpoint = "https://api.foursquare.com/v3/places/";

        public static async Task<List<Restaurante>> GetRestaurantsAsync(string latitude, string longitude)
        {
            var listaRestaurantes = new List<Restaurante>();

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Accept", "application/json");
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {apiKey}");
                client.DefaultRequestHeaders.Add("X-Places-Api-Version", "2025-06-17");

                string url = $"{searchEndpoint}?ll={latitude},{longitude}&radius=5000&limit=50&query=restaurante";

                try
                {
                    var response = await client.GetAsync(url);
                    if (!response.IsSuccessStatusCode)
                    {
                        throw new Exception("Erro ao buscar dados da API: " + response.ReasonPhrase);
                    }

                    string content = await response.Content.ReadAsStringAsync();
                    JObject json = JObject.Parse(content);

                    foreach (var item in json["results"])
                    {
                        string id = item["fsq_id"]?.ToString();
                        string nome = item["name"]?.ToString();
                        string endereco = item["location"]?["formatted_address"]?.ToString();
                        string categoria = item["categories"]?[0]?["name"]?.ToString();

                        // Segunda requisição para obter detalhes (contato, rating, etc.)
                        string detalhesUrl = $"{detailsEndpoint}{id}";
                        var detalhesResponse = await client.GetAsync(detalhesUrl);
                        string detalhesContent = await detalhesResponse.Content.ReadAsStringAsync();
                        JObject detalhesJson = JObject.Parse(detalhesContent);

                        string contato = detalhesJson["contact"]?["formatted_phone"]?.ToString() ?? "Não informado";
                        string avaliacao = detalhesJson["rating"]?.ToString() ?? "Sem avaliação";

                        if (!string.IsNullOrEmpty(nome) && !string.IsNullOrEmpty(endereco))
                        {
                            var restaurante = new Restaurante
                            {
                                id = id,
                                Nome = nome,
                                Endereco = endereco,
                                Contato = contato,
                                Categoria = categoria,
                                Avaliacao = avaliacao
                            };

                            listaRestaurantes.Add(restaurante);

                            // Mostrar nome para testar
                            //MessageBox.Show($"Restaurante encontrado: {restaurante.Nome}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao buscar restaurantes: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                return listaRestaurantes;
            }
        }
    }
}
