using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace LocalPerfeito
{
    public partial class carregamento : Form
    {
        public carregamento()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.None; // Remove a borda do formul�rio
            this.StartPosition = FormStartPosition.CenterScreen; // Centraliza o formul�rio na tela


        }
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hWnd, int msg, int wParam, int lParam);
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HTCAPTION = 0x2;

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        bool jaAbriu = false;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!jaAbriu)
            {
                jaAbriu = true;
                timer1.Stop();

                Login loginForm = new Login();
                loginForm.Show(); // Exibe o formul�rio de login
                this.Hide(); // Esconde o formul�rio de carregamento

            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
        }
    }
}
