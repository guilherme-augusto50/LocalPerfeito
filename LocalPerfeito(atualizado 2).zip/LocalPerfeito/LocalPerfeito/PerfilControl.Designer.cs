﻿namespace LocalPerfeito
{
    partial class PerfilControl
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox4 = new PictureBox();
            menuStrip = new MenuStrip();
            inícioToolStripMenuItem = new ToolStripMenuItem();
            variedadesToolStripMenuItem = new ToolStripMenuItem();
            favoritosToolStripMenuItem = new ToolStripMenuItem();
            perfilToolStripMenuItem = new ToolStripMenuItem();
            suporteToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            textBox1 = new TextBox();
            label2 = new Label();
            panel1 = new Panel();
            panel2 = new Panel();
            lblNomeUsuario = new Label();
            pictureBox1 = new PictureBox();
            panel3 = new Panel();
            btnLimpar = new Button();
            label3 = new Label();
            dataGridView1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            menuStrip.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.logo_localperfeito;
            pictureBox4.Location = new Point(0, 9);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(138, 67);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 12;
            pictureBox4.TabStop = false;
            // 
            // menuStrip
            // 
            menuStrip.BackColor = Color.White;
            menuStrip.Dock = DockStyle.None;
            menuStrip.Items.AddRange(new ToolStripItem[] { inícioToolStripMenuItem, variedadesToolStripMenuItem, favoritosToolStripMenuItem, perfilToolStripMenuItem, suporteToolStripMenuItem });
            menuStrip.LayoutStyle = ToolStripLayoutStyle.VerticalStackWithOverflow;
            menuStrip.Location = new Point(5, 90);
            menuStrip.Name = "menuStrip";
            menuStrip.Padding = new Padding(5, 5, 8, 10);
            menuStrip.RenderMode = ToolStripRenderMode.Professional;
            menuStrip.Size = new Size(106, 392);
            menuStrip.TabIndex = 18;
            menuStrip.ItemClicked += menuStrip_ItemClicked;
            // 
            // inícioToolStripMenuItem
            // 
            inícioToolStripMenuItem.Checked = true;
            inícioToolStripMenuItem.CheckState = CheckState.Checked;
            inícioToolStripMenuItem.Image = Properties.Resources.grid_web_7__1_;
            inícioToolStripMenuItem.Name = "inícioToolStripMenuItem";
            inícioToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            inícioToolStripMenuItem.Size = new Size(92, 75);
            inícioToolStripMenuItem.Text = "Início";
            inícioToolStripMenuItem.Click += inícioToolStripMenuItem_Click;
            // 
            // variedadesToolStripMenuItem
            // 
            variedadesToolStripMenuItem.Image = Properties.Resources.store;
            variedadesToolStripMenuItem.Name = "variedadesToolStripMenuItem";
            variedadesToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            variedadesToolStripMenuItem.Size = new Size(92, 75);
            variedadesToolStripMenuItem.Text = "Variedades";
            // 
            // favoritosToolStripMenuItem
            // 
            favoritosToolStripMenuItem.Image = Properties.Resources.star;
            favoritosToolStripMenuItem.Name = "favoritosToolStripMenuItem";
            favoritosToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            favoritosToolStripMenuItem.Size = new Size(92, 75);
            favoritosToolStripMenuItem.Text = "Favoritos";
            // 
            // perfilToolStripMenuItem
            // 
            perfilToolStripMenuItem.Image = Properties.Resources.users_group_alt__1_;
            perfilToolStripMenuItem.Name = "perfilToolStripMenuItem";
            perfilToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            perfilToolStripMenuItem.Size = new Size(92, 75);
            perfilToolStripMenuItem.Text = "Perfil";
            // 
            // suporteToolStripMenuItem
            // 
            suporteToolStripMenuItem.Image = Properties.Resources.lightbulb;
            suporteToolStripMenuItem.Name = "suporteToolStripMenuItem";
            suporteToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            suporteToolStripMenuItem.Size = new Size(92, 75);
            suporteToolStripMenuItem.Text = "Suporte";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Location = new Point(154, 44);
            label1.Name = "label1";
            label1.Size = new Size(181, 15);
            label1.TabIndex = 19;
            label1.Text = "Locais que você marcou para ir ;)";
            label1.Click += label1_Click_1;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Top;
            textBox1.BackColor = Color.FromArgb(229, 229, 234);
            textBox1.Location = new Point(365, 25);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Pesquisa";
            textBox1.Size = new Size(232, 23);
            textBox1.TabIndex = 13;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Font = new Font("Impact", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(154, 21);
            label2.Name = "label2";
            label2.Size = new Size(69, 23);
            label2.TabIndex = 16;
            label2.Text = "Agenda";
            label2.Click += label2_Click;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel1.BackColor = Color.White;
            panel1.Location = new Point(144, 9);
            panel1.Name = "panel1";
            panel1.Size = new Size(628, 67);
            panel1.TabIndex = 20;
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            panel2.BackColor = Color.White;
            panel2.Controls.Add(lblNomeUsuario);
            panel2.Controls.Add(pictureBox1);
            panel2.Location = new Point(588, 90);
            panel2.Name = "panel2";
            panel2.Size = new Size(184, 392);
            panel2.TabIndex = 21;
            // 
            // lblNomeUsuario
            // 
            lblNomeUsuario.AutoSize = true;
            lblNomeUsuario.Location = new Point(62, 151);
            lblNomeUsuario.Name = "lblNomeUsuario";
            lblNomeUsuario.Size = new Size(47, 15);
            lblNomeUsuario.TabIndex = 1;
            lblNomeUsuario.Text = "Usuário";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.user_icon_vector;
            pictureBox1.Location = new Point(27, 19);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(120, 120);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // panel3
            // 
            panel3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panel3.BackColor = Color.White;
            panel3.Controls.Add(btnLimpar);
            panel3.Controls.Add(label3);
            panel3.Controls.Add(dataGridView1);
            panel3.Location = new Point(133, 109);
            panel3.Name = "panel3";
            panel3.Size = new Size(431, 373);
            panel3.TabIndex = 22;
            // 
            // btnLimpar
            // 
            btnLimpar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnLimpar.BackColor = Color.Transparent;
            btnLimpar.ForeColor = Color.FromArgb(249, 0, 232);
            btnLimpar.Location = new Point(335, 20);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(75, 23);
            btnLimpar.TabIndex = 2;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(21, 19);
            label3.Name = "label3";
            label3.Size = new Size(82, 21);
            label3.TabIndex = 1;
            label3.Text = "Marcados";
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(21, 54);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(389, 302);
            dataGridView1.TabIndex = 0;
            // 
            // PerfilControl
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(229, 229, 234);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(panel1);
            Controls.Add(pictureBox4);
            Controls.Add(menuStrip);
            Name = "PerfilControl";
            Size = new Size(848, 450);
            Load += PerfilControl_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            menuStrip.ResumeLayout(false);
            menuStrip.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox4;
        private MenuStrip menuStrip;
        private ToolStripMenuItem inícioToolStripMenuItem;
        private ToolStripMenuItem variedadesToolStripMenuItem;
        private ToolStripMenuItem favoritosToolStripMenuItem;
        private ToolStripMenuItem perfilToolStripMenuItem;
        private ToolStripMenuItem suporteToolStripMenuItem;
        private Label label1;
        private TextBox textBox1;
        private Label label2;
        private Panel panel1;
        private Panel panel2;
        private Label lblNomeUsuario;
        private PictureBox pictureBox1;
        private Panel panel3;
        private Button btnLimpar;
        private Label label3;
        private DataGridView dataGridView1;
    }
}
