﻿namespace LocalPerfeito
{
    partial class telaprincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(telaprincipal));
            panel1 = new Panel();
            pictureBox4 = new PictureBox();
            guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            lblSuporte = new Label();
            lblPerfil = new Label();
            pictureBox1 = new PictureBox();
            lblFavoritos = new Label();
            pictureBox6 = new PictureBox();
            lblVariedades = new Label();
            pictureBox3 = new PictureBox();
            pictureBox5 = new PictureBox();
            label1 = new Label();
            pictureBox2 = new PictureBox();
            textBox1 = new TextBox();
            flowRestaurantes = new FlowLayoutPanel();
            pictureBox8 = new PictureBox();
            pictureBox7 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            guna2CustomGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            flowRestaurantes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(229, 229, 234);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(guna2CustomGradientPanel1);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(flowRestaurantes);
            panel1.Controls.Add(pictureBox7);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 450);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.logo_localperfeito;
            pictureBox4.Location = new Point(3, 3);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(166, 85);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 0;
            pictureBox4.TabStop = false;
            // 
            // guna2CustomGradientPanel1
            // 
            guna2CustomGradientPanel1.BorderRadius = 15;
            guna2CustomGradientPanel1.Controls.Add(lblSuporte);
            guna2CustomGradientPanel1.Controls.Add(lblPerfil);
            guna2CustomGradientPanel1.Controls.Add(pictureBox1);
            guna2CustomGradientPanel1.Controls.Add(lblFavoritos);
            guna2CustomGradientPanel1.Controls.Add(pictureBox6);
            guna2CustomGradientPanel1.Controls.Add(lblVariedades);
            guna2CustomGradientPanel1.Controls.Add(pictureBox3);
            guna2CustomGradientPanel1.Controls.Add(pictureBox5);
            guna2CustomGradientPanel1.Controls.Add(label1);
            guna2CustomGradientPanel1.Controls.Add(pictureBox2);
            guna2CustomGradientPanel1.CustomizableEdges = customizableEdges1;
            guna2CustomGradientPanel1.Location = new Point(0, 94);
            guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            guna2CustomGradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2CustomGradientPanel1.Size = new Size(169, 423);
            guna2CustomGradientPanel1.TabIndex = 4;
            guna2CustomGradientPanel1.Visible = false;
            // 
            // lblSuporte
            // 
            lblSuporte.AutoSize = true;
            lblSuporte.BackColor = Color.Transparent;
            lblSuporte.Font = new Font("Arial", 12F);
            lblSuporte.Location = new Point(48, 248);
            lblSuporte.Name = "lblSuporte";
            lblSuporte.Size = new Size(63, 18);
            lblSuporte.TabIndex = 8;
            lblSuporte.Text = "Suporte";
            // 
            // lblPerfil
            // 
            lblPerfil.AutoSize = true;
            lblPerfil.BackColor = Color.Transparent;
            lblPerfil.Font = new Font("Arial", 12F);
            lblPerfil.Location = new Point(48, 195);
            lblPerfil.Name = "lblPerfil";
            lblPerfil.Size = new Size(44, 18);
            lblPerfil.TabIndex = 7;
            lblPerfil.Text = "Perfil";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.lightbulb;
            pictureBox1.Location = new Point(21, 248);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(15, 19);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            // 
            // lblFavoritos
            // 
            lblFavoritos.AutoSize = true;
            lblFavoritos.BackColor = Color.Transparent;
            lblFavoritos.Font = new Font("Arial", 12F);
            lblFavoritos.Location = new Point(48, 143);
            lblFavoritos.Name = "lblFavoritos";
            lblFavoritos.Size = new Size(73, 18);
            lblFavoritos.TabIndex = 6;
            lblFavoritos.Text = "Favoritos";
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.users_group_alt__1_;
            pictureBox6.Location = new Point(16, 195);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(23, 18);
            pictureBox6.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox6.TabIndex = 9;
            pictureBox6.TabStop = false;
            // 
            // lblVariedades
            // 
            lblVariedades.AutoSize = true;
            lblVariedades.BackColor = Color.Transparent;
            lblVariedades.Font = new Font("Arial", 12F);
            lblVariedades.Location = new Point(48, 92);
            lblVariedades.Name = "lblVariedades";
            lblVariedades.Size = new Size(89, 18);
            lblVariedades.TabIndex = 5;
            lblVariedades.Text = "Variedades";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.store;
            pictureBox3.Location = new Point(16, 92);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(18, 18);
            pictureBox3.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox3.TabIndex = 8;
            pictureBox3.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.star;
            pictureBox5.Location = new Point(16, 143);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(20, 18);
            pictureBox5.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox5.TabIndex = 8;
            pictureBox5.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Arial", 12F);
            label1.Location = new Point(43, 36);
            label1.Name = "label1";
            label1.Size = new Size(43, 18);
            label1.TabIndex = 5;
            label1.Text = "Início";
            label1.Click += label1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.grid_web_7__3_;
            pictureBox2.Location = new Point(18, 38);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(16, 16);
            pictureBox2.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox2.TabIndex = 6;
            pictureBox2.TabStop = false;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Top;
            textBox1.Location = new Point(341, 12);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Pesquisa";
            textBox1.Size = new Size(284, 23);
            textBox1.TabIndex = 1;
            // 
            // flowRestaurantes
            // 
            flowRestaurantes.AutoScroll = true;
            flowRestaurantes.BackColor = Color.White;
            flowRestaurantes.Controls.Add(pictureBox8);
            flowRestaurantes.Location = new Point(172, 86);
            flowRestaurantes.Name = "flowRestaurantes";
            flowRestaurantes.Size = new Size(625, 431);
            flowRestaurantes.TabIndex = 5;
            flowRestaurantes.Paint += flowRestaurantes_Paint;
            // 
            // pictureBox8
            // 
            pictureBox8.Location = new Point(3, 3);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(193, 200);
            pictureBox8.TabIndex = 0;
            pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureBox7.Image = Properties.Resources.user_icon_vector;
            pictureBox7.Location = new Point(697, 3);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(100, 50);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 2;
            pictureBox7.TabStop = false;
            // 
            // telaprincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "telaprincipal";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "telaprincipal";
            WindowState = FormWindowState.Maximized;
            FormClosing += telaprincipal_FormClosing;
            FormClosed += telaprincipal_FormClosed;
            Load += telaprincipal_Load_1;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            guna2CustomGradientPanel1.ResumeLayout(false);
            guna2CustomGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            flowRestaurantes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private Label lblSuporte;
        private Label lblPerfil;
        private Label lblFavoritos;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private PictureBox pictureBox1;
        private Label lblVariedades;
        private FlowLayoutPanel flowRestaurantes;
        private PictureBox pictureBox4;
        private TextBox textBox1;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
    }
}