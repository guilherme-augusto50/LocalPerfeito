﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json.Linq;

namespace LocalPerfeito
{
    public class LocalizacaoHelper
    {
        public static async Task<(string Latitude, string Longitude)> ObterCoordenadasAsync()
        {
            string latitude = "40.748817"; // Padrão: Latitude de Nova York
            string longitude = "-73.985428"; // Padrão: Longitude de Nova York

            using (HttpClient client = new HttpClient())
            {
                try {
                    var json = await client.GetStringAsync("https://ipapi.co/json");
                    dynamic data = JObject.Parse(json);
                    latitude = data.latitude ?? latitude;
                    longitude = data.longitude ?? longitude;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao obter coordenadas: {ex.Message}");
                    return (latitude, longitude);
                }
            }
            return (latitude, longitude);
        }
    }
}

