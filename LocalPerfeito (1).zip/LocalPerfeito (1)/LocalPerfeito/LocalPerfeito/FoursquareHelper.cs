﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;

namespace LocalPerfeito
{
    public class Restaurante
    {
        public int id;
        public string nome;
        public string endereco;
        public string telefone;
        public string categoria;
        public double avaliacao;
        public string imagemUrl;
        
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        public string Endereco
        {
            get { return endereco; }
            set { endereco = value; }
        }
        public string Telefone
        {
            get { return telefone; }
            set { telefone = value; }
        }
        public string Categoria
        {
            get { return categoria; }
            set { categoria = value; }
        }
        public double Avaliacao
        {
            get { return avaliacao; }
            set { avaliacao = value; }
        }
        public string ImagemUrl
        {
            get { return imagemUrl; }
            set { imagemUrl = value; }
        }

    }

    public class FoursquareHelper
    {
        private const string apikey = "fsq3PUBLICKEY123456789"; // Chave simulada
        
        public static async Task<List<Restaurante>> BuscarRestaurantesAsync(string latitude, string longitude)
        {
            List<Restaurante> restaurantes = new List<Restaurante>();
            string url = "https://api.foursquare.com/v3/places/search?ll={latitude},{longitude}&categories=13065&limit=10";

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", apikey);
                try {
                    string response = await client.GetStringAsync(url);
                    JObject json = JObject.Parse(response);
                    JArray results = (JArray)json["results"];

                    foreach (var item in results)
                    {
                        var nome = item["name"]?.ToString() ?? "Sem nome";
                        var endereco = item["location"]?["formatted_address"]?.ToString() ?? "Sem endereço";
                        var id = item["fsq_id"]?.ToString() ?? "";
                        var avaliacao = item["rating"]?.ToObject<double?>() ?? 0;
                        var telefone = item["phone"]?.ToString() ?? "Sem telefone";
                        var categoria = item["categories"]?[0]?["name"]?.ToString() ?? "Sem categoria";

                        string imagemUrl = await BuscarImagemAsync(id);


                        restaurantes.Add(new Restaurante
                        {
                            Id = int.Parse(id),
                            Nome = nome,
                            Endereco = endereco,
                            Telefone = telefone,
                            Categoria = categoria,
                            Avaliacao = avaliacao,
                            ImagemUrl = imagemUrl
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao buscar restaurantes: {ex.Message}");
                    return restaurantes;
                }
            }
            return restaurantes;
        }
        private static async Task<string> BuscarImagemAsync(string fsqId)
        {
            string url = $"https://api.foursquare.com/v3/places/{fsqId}/photos?limit=1";
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", apikey);
                try {
                    string response = await client.GetStringAsync(url);
                    JObject json = JObject.Parse(response);
                    JArray photos = (JArray)json["results"];
                    if (photos.Count > 0)
                    {
                        var photo = photos[0];
                        string prefix = photo["prefix"].ToString();
                        string suffix = photo["suffix"].ToString();
                        return $"{prefix}original{suffix}";
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao buscar imagem: {ex.Message}");
                }
                return "https://via.placeholder.com/300"; // Retorna uma imagem padrão se não encontrar
            }
        }
    }   
}
