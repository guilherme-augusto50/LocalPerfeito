﻿namespace LocalPerfeito
{
    partial class Suporte
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            panel3 = new Panel();
            panel4 = new Panel();
            textBox1 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            pictureBox4 = new PictureBox();
            menuStrip = new MenuStrip();
            inícioToolStripMenuItem = new ToolStripMenuItem();
            favoritosToolStripMenuItem = new ToolStripMenuItem();
            perfilToolStripMenuItem = new ToolStripMenuItem();
            suporteToolStripMenuItem = new ToolStripMenuItem();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            menuStrip.SuspendLayout();
            guna2CustomGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(menuStrip);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 450);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // panel3
            // 
            panel3.BackColor = Color.White;
            panel3.Controls.Add(pictureBox1);
            panel3.Controls.Add(guna2CustomGradientPanel1);
            panel3.Location = new Point(147, 84);
            panel3.Name = "panel3";
            panel3.Size = new Size(626, 414);
            panel3.TabIndex = 30;
            // 
            // panel4
            // 
            panel4.BackColor = Color.White;
            panel4.Controls.Add(textBox1);
            panel4.Controls.Add(label1);
            panel4.Controls.Add(label2);
            panel4.Location = new Point(147, 14);
            panel4.Name = "panel4";
            panel4.Size = new Size(639, 50);
            panel4.TabIndex = 28;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Top;
            textBox1.BackColor = Color.FromArgb(229, 229, 234);
            textBox1.Location = new Point(233, 11);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Pesquisa";
            textBox1.Size = new Size(232, 23);
            textBox1.TabIndex = 24;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Location = new Point(21, 30);
            label1.Name = "label1";
            label1.Size = new Size(154, 15);
            label1.TabIndex = 27;
            label1.Text = "Caso queira alguma ajuda ;)";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Font = new Font("Impact", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(21, 7);
            label2.Name = "label2";
            label2.Size = new Size(73, 23);
            label2.TabIndex = 25;
            label2.Text = "Suporte";
            label2.Click += label2_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.logo_localperfeito;
            pictureBox4.Location = new Point(3, 14);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(138, 67);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 23;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // menuStrip
            // 
            menuStrip.BackColor = Color.White;
            menuStrip.Dock = DockStyle.None;
            menuStrip.Items.AddRange(new ToolStripItem[] { inícioToolStripMenuItem, favoritosToolStripMenuItem, perfilToolStripMenuItem, suporteToolStripMenuItem });
            menuStrip.LayoutStyle = ToolStripLayoutStyle.VerticalStackWithOverflow;
            menuStrip.Location = new Point(8, 84);
            menuStrip.Name = "menuStrip";
            menuStrip.Padding = new Padding(5, 5, 8, 10);
            menuStrip.RenderMode = ToolStripRenderMode.Professional;
            menuStrip.Size = new Size(98, 317);
            menuStrip.TabIndex = 26;
            // 
            // inícioToolStripMenuItem
            // 
            inícioToolStripMenuItem.Checked = true;
            inícioToolStripMenuItem.CheckState = CheckState.Checked;
            inícioToolStripMenuItem.Image = Properties.Resources.grid_web_7__1_;
            inícioToolStripMenuItem.Name = "inícioToolStripMenuItem";
            inícioToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            inícioToolStripMenuItem.Size = new Size(84, 75);
            inícioToolStripMenuItem.Text = "Início";
            // 
            // favoritosToolStripMenuItem
            // 
            favoritosToolStripMenuItem.Image = Properties.Resources.star;
            favoritosToolStripMenuItem.Name = "favoritosToolStripMenuItem";
            favoritosToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            favoritosToolStripMenuItem.Size = new Size(84, 75);
            favoritosToolStripMenuItem.Text = "Favoritos";
            // 
            // perfilToolStripMenuItem
            // 
            perfilToolStripMenuItem.Image = Properties.Resources.users_group_alt__1_;
            perfilToolStripMenuItem.Name = "perfilToolStripMenuItem";
            perfilToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            perfilToolStripMenuItem.Size = new Size(84, 75);
            perfilToolStripMenuItem.Text = "Perfil";
            // 
            // suporteToolStripMenuItem
            // 
            suporteToolStripMenuItem.Image = Properties.Resources.lightbulb;
            suporteToolStripMenuItem.Name = "suporteToolStripMenuItem";
            suporteToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            suporteToolStripMenuItem.Size = new Size(84, 75);
            suporteToolStripMenuItem.Text = "Suporte";
            // 
            // guna2Button1
            // 
            guna2Button1.CustomizableEdges = customizableEdges1;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.FillColor = Color.FromArgb(249, 0, 232);
            guna2Button1.Font = new Font("Segoe UI", 9F);
            guna2Button1.ForeColor = Color.White;
            guna2Button1.Location = new Point(16, 129);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2Button1.Size = new Size(124, 21);
            guna2Button1.TabIndex = 5;
            guna2Button1.Text = "Entrar em contato";
            // 
            // guna2CustomGradientPanel1
            // 
            guna2CustomGradientPanel1.BackColor = Color.FromArgb(229, 229, 234);
            guna2CustomGradientPanel1.Controls.Add(guna2Button1);
            guna2CustomGradientPanel1.CustomizableEdges = customizableEdges3;
            guna2CustomGradientPanel1.Location = new Point(447, 23);
            guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            guna2CustomGradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2CustomGradientPanel1.Size = new Size(154, 340);
            guna2CustomGradientPanel1.TabIndex = 6;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.local_perfeito_tutorial1;
            pictureBox1.Location = new Point(21, 23);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(397, 281);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // Suporte
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel1);
            Name = "Suporte";
            Size = new Size(800, 450);
            Load += Suporte_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel3.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            menuStrip.ResumeLayout(false);
            menuStrip.PerformLayout();
            guna2CustomGradientPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel3;
        private Label label1;
        private Label label2;
        private TextBox textBox1;
        private Panel panel4;
        private PictureBox pictureBox4;
        private MenuStrip menuStrip;
        private ToolStripMenuItem inícioToolStripMenuItem;
        private ToolStripMenuItem favoritosToolStripMenuItem;
        private ToolStripMenuItem perfilToolStripMenuItem;
        private ToolStripMenuItem suporteToolStripMenuItem;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private PictureBox pictureBox1;
    }
}
