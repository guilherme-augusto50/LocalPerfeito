﻿namespace LocalPerfeito
{
    partial class cadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(cadastro));
            panel1 = new Panel();
            guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            label1 = new Label();
            guna2Separator4 = new Guna.UI2.WinForms.Guna2Separator();
            guna2Separator3 = new Guna.UI2.WinForms.Guna2Separator();
            guna2Separator2 = new Guna.UI2.WinForms.Guna2Separator();
            guna2Separator1 = new Guna.UI2.WinForms.Guna2Separator();
            txtNome = new Guna.UI2.WinForms.Guna2TextBox();
            linkLabel1 = new LinkLabel();
            txtEmail = new Guna.UI2.WinForms.Guna2TextBox();
            label4 = new Label();
            txtSenha = new Guna.UI2.WinForms.Guna2TextBox();
            btncadastrese = new Guna.UI2.WinForms.Guna2Button();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            guna2ShadowPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(guna2ShadowPanel1);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 450);
            panel1.TabIndex = 0;
            // 
            // guna2ShadowPanel1
            // 
            guna2ShadowPanel1.BackColor = Color.Transparent;
            guna2ShadowPanel1.Controls.Add(label1);
            guna2ShadowPanel1.Controls.Add(guna2Separator4);
            guna2ShadowPanel1.Controls.Add(guna2Separator3);
            guna2ShadowPanel1.Controls.Add(guna2Separator2);
            guna2ShadowPanel1.Controls.Add(guna2Separator1);
            guna2ShadowPanel1.Controls.Add(txtNome);
            guna2ShadowPanel1.Controls.Add(linkLabel1);
            guna2ShadowPanel1.Controls.Add(txtEmail);
            guna2ShadowPanel1.Controls.Add(label4);
            guna2ShadowPanel1.Controls.Add(txtSenha);
            guna2ShadowPanel1.Controls.Add(btncadastrese);
            guna2ShadowPanel1.FillColor = Color.White;
            guna2ShadowPanel1.Location = new Point(271, 113);
            guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            guna2ShadowPanel1.Radius = 6;
            guna2ShadowPanel1.ShadowColor = Color.Black;
            guna2ShadowPanel1.Size = new Size(308, 325);
            guna2ShadowPanel1.TabIndex = 10;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft YaHei UI", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Gray;
            label1.Location = new Point(62, 22);
            label1.Name = "label1";
            label1.Size = new Size(165, 26);
            label1.TabIndex = 14;
            label1.Text = "Criar uma conta";
            // 
            // guna2Separator4
            // 
            guna2Separator4.Location = new Point(28, 271);
            guna2Separator4.Name = "guna2Separator4";
            guna2Separator4.Size = new Size(247, 10);
            guna2Separator4.TabIndex = 13;
            // 
            // guna2Separator3
            // 
            guna2Separator3.Location = new Point(28, 193);
            guna2Separator3.Name = "guna2Separator3";
            guna2Separator3.Size = new Size(247, 10);
            guna2Separator3.TabIndex = 12;
            // 
            // guna2Separator2
            // 
            guna2Separator2.Location = new Point(28, 148);
            guna2Separator2.Name = "guna2Separator2";
            guna2Separator2.Size = new Size(247, 10);
            guna2Separator2.TabIndex = 11;
            // 
            // guna2Separator1
            // 
            guna2Separator1.Location = new Point(28, 103);
            guna2Separator1.Name = "guna2Separator1";
            guna2Separator1.Size = new Size(247, 10);
            guna2Separator1.TabIndex = 10;
            // 
            // txtNome
            // 
            txtNome.CustomizableEdges = customizableEdges1;
            txtNome.DefaultText = "";
            txtNome.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtNome.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtNome.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtNome.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtNome.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNome.Font = new Font("Segoe UI", 9F);
            txtNome.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNome.Location = new Point(28, 74);
            txtNome.Name = "txtNome";
            txtNome.PlaceholderText = "Nome";
            txtNome.SelectedText = "";
            txtNome.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtNome.Size = new Size(247, 23);
            txtNome.TabIndex = 4;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.LinkColor = Color.FromArgb(255, 128, 255);
            linkLabel1.Location = new Point(177, 284);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(57, 15);
            linkLabel1.TabIndex = 9;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Faz Login";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // txtEmail
            // 
            txtEmail.CustomizableEdges = customizableEdges3;
            txtEmail.DefaultText = "";
            txtEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Font = new Font("Segoe UI", 9F);
            txtEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Location = new Point(28, 119);
            txtEmail.Name = "txtEmail";
            txtEmail.PlaceholderText = "Email";
            txtEmail.SelectedText = "";
            txtEmail.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtEmail.Size = new Size(247, 23);
            txtEmail.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(62, 284);
            label4.Name = "label4";
            label4.Size = new Size(109, 15);
            label4.TabIndex = 8;
            label4.Text = "Já tem uma conta ?";
            // 
            // txtSenha
            // 
            txtSenha.CustomizableEdges = customizableEdges5;
            txtSenha.DefaultText = "";
            txtSenha.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtSenha.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtSenha.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtSenha.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtSenha.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSenha.Font = new Font("Segoe UI", 9F);
            txtSenha.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSenha.Location = new Point(28, 164);
            txtSenha.Name = "txtSenha";
            txtSenha.PlaceholderForeColor = Color.FromArgb(198, 200, 217);
            txtSenha.PlaceholderText = "Senha";
            txtSenha.SelectedText = "";
            txtSenha.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtSenha.Size = new Size(247, 23);
            txtSenha.TabIndex = 6;
            // 
            // btncadastrese
            // 
            btncadastrese.BorderRadius = 6;
            btncadastrese.CustomizableEdges = customizableEdges7;
            btncadastrese.DisabledState.BorderColor = Color.DarkGray;
            btncadastrese.DisabledState.CustomBorderColor = Color.DarkGray;
            btncadastrese.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btncadastrese.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btncadastrese.FillColor = Color.FromArgb(255, 128, 255);
            btncadastrese.Font = new Font("Segoe UI", 9F);
            btncadastrese.ForeColor = Color.White;
            btncadastrese.Location = new Point(45, 224);
            btncadastrese.Name = "btncadastrese";
            btncadastrese.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btncadastrese.Size = new Size(189, 29);
            btncadastrese.TabIndex = 7;
            btncadastrese.Text = "Cadastra-se";
            btncadastrese.Click += btncadastrese_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.logo_localperfeito;
            pictureBox1.Location = new Point(308, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(238, 95);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // cadastro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(211, 193, 255);
            ClientSize = new Size(800, 450);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "cadastro";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "cadastro";
            FormClosing += cadastro_FormClosing;
            FormClosed += cadastro_FormClosed;
            panel1.ResumeLayout(false);
            guna2ShadowPanel1.ResumeLayout(false);
            guna2ShadowPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Guna.UI2.WinForms.Guna2Button btncadastrese;
        private Guna.UI2.WinForms.Guna2TextBox txtSenha;
        private Guna.UI2.WinForms.Guna2TextBox txtEmail;
        private Guna.UI2.WinForms.Guna2TextBox txtNome;
        private PictureBox pictureBox1;
        private LinkLabel linkLabel1;
        private Label label4;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator4;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator3;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator2;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator1;
    }
}