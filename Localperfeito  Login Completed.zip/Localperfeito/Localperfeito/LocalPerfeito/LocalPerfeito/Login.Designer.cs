﻿namespace LocalPerfeito
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.AnimatorNS.Animation animation4 = new Guna.UI2.AnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            panel1 = new Panel();
            guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            label1 = new Label();
            guna2Separator1 = new Guna.UI2.WinForms.Guna2Separator();
            guna2Separator2 = new Guna.UI2.WinForms.Guna2Separator();
            txtEmail = new Guna.UI2.WinForms.Guna2TextBox();
            linkLabel1 = new LinkLabel();
            picmostrarocultar = new PictureBox();
            label3 = new Label();
            groupBox1 = new GroupBox();
            btnGoogleLogin = new Guna.UI2.WinForms.Guna2Button();
            btnLogar = new Guna.UI2.WinForms.Guna2Button();
            txtSenha = new Guna.UI2.WinForms.Guna2TextBox();
            pictureBox1 = new PictureBox();
            guna2Transition1 = new Guna.UI2.WinForms.Guna2Transition();
            guna2Separator3 = new Guna.UI2.WinForms.Guna2Separator();
            panel1.SuspendLayout();
            guna2ShadowPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picmostrarocultar).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(211, 193, 252);
            panel1.Controls.Add(guna2ShadowPanel1);
            panel1.Controls.Add(pictureBox1);
            guna2Transition1.SetDecoration(panel1, Guna.UI2.AnimatorNS.DecorationType.None);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 450);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // guna2ShadowPanel1
            // 
            guna2ShadowPanel1.BackColor = Color.Transparent;
            guna2ShadowPanel1.Controls.Add(guna2Separator3);
            guna2ShadowPanel1.Controls.Add(label1);
            guna2ShadowPanel1.Controls.Add(guna2Separator1);
            guna2ShadowPanel1.Controls.Add(guna2Separator2);
            guna2ShadowPanel1.Controls.Add(txtEmail);
            guna2ShadowPanel1.Controls.Add(linkLabel1);
            guna2ShadowPanel1.Controls.Add(picmostrarocultar);
            guna2ShadowPanel1.Controls.Add(label3);
            guna2ShadowPanel1.Controls.Add(groupBox1);
            guna2ShadowPanel1.Controls.Add(btnLogar);
            guna2ShadowPanel1.Controls.Add(txtSenha);
            guna2Transition1.SetDecoration(guna2ShadowPanel1, Guna.UI2.AnimatorNS.DecorationType.None);
            guna2ShadowPanel1.FillColor = Color.White;
            guna2ShadowPanel1.Location = new Point(272, 100);
            guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            guna2ShadowPanel1.Radius = 6;
            guna2ShadowPanel1.ShadowColor = Color.Black;
            guna2ShadowPanel1.Size = new Size(324, 338);
            guna2ShadowPanel1.TabIndex = 12;
            // 
            // label1
            // 
            label1.AutoSize = true;
            guna2Transition1.SetDecoration(label1, Guna.UI2.AnimatorNS.DecorationType.None);
            label1.Font = new Font("Microsoft YaHei", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Gray;
            label1.Location = new Point(63, 24);
            label1.Name = "label1";
            label1.Size = new Size(192, 26);
            label1.TabIndex = 14;
            label1.Text = "Logar na sua conta";
            // 
            // guna2Separator1
            // 
            guna2Transition1.SetDecoration(guna2Separator1, Guna.UI2.AnimatorNS.DecorationType.None);
            guna2Separator1.Location = new Point(41, 106);
            guna2Separator1.Name = "guna2Separator1";
            guna2Separator1.Size = new Size(253, 10);
            guna2Separator1.TabIndex = 12;
            // 
            // guna2Separator2
            // 
            guna2Transition1.SetDecoration(guna2Separator2, Guna.UI2.AnimatorNS.DecorationType.None);
            guna2Separator2.Location = new Point(43, 151);
            guna2Separator2.Name = "guna2Separator2";
            guna2Separator2.Size = new Size(253, 10);
            guna2Separator2.TabIndex = 13;
            // 
            // txtEmail
            // 
            txtEmail.CustomizableEdges = customizableEdges25;
            guna2Transition1.SetDecoration(txtEmail, Guna.UI2.AnimatorNS.DecorationType.None);
            txtEmail.DefaultText = "";
            txtEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Font = new Font("Segoe UI", 9F);
            txtEmail.ForeColor = Color.Black;
            txtEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Location = new Point(45, 77);
            txtEmail.Name = "txtEmail";
            txtEmail.PlaceholderText = "Email";
            txtEmail.SelectedText = "";
            txtEmail.ShadowDecoration.CustomizableEdges = customizableEdges26;
            txtEmail.Size = new Size(253, 23);
            txtEmail.TabIndex = 5;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            guna2Transition1.SetDecoration(linkLabel1, Guna.UI2.AnimatorNS.DecorationType.None);
            linkLabel1.LinkColor = Color.Fuchsia;
            linkLabel1.Location = new Point(173, 303);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(84, 15);
            linkLabel1.TabIndex = 7;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Fazer Cadastro";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // picmostrarocultar
            // 
            picmostrarocultar.BackColor = Color.Transparent;
            guna2Transition1.SetDecoration(picmostrarocultar, Guna.UI2.AnimatorNS.DecorationType.None);
            picmostrarocultar.Image = Properties.Resources.eye_off;
            picmostrarocultar.Location = new Point(276, 120);
            picmostrarocultar.Name = "picmostrarocultar";
            picmostrarocultar.Size = new Size(22, 25);
            picmostrarocultar.SizeMode = PictureBoxSizeMode.StretchImage;
            picmostrarocultar.TabIndex = 10;
            picmostrarocultar.TabStop = false;
            picmostrarocultar.Click += pictureBox2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            guna2Transition1.SetDecoration(label3, Guna.UI2.AnimatorNS.DecorationType.None);
            label3.Location = new Point(63, 303);
            label3.Name = "label3";
            label3.Size = new Size(104, 15);
            label3.TabIndex = 8;
            label3.Text = "não tem cadastro?";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnGoogleLogin);
            guna2Transition1.SetDecoration(groupBox1, Guna.UI2.AnimatorNS.DecorationType.None);
            groupBox1.Location = new Point(43, 167);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(253, 63);
            groupBox1.TabIndex = 9;
            groupBox1.TabStop = false;
            groupBox1.Text = "Entrar com:";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // btnGoogleLogin
            // 
            btnGoogleLogin.CustomizableEdges = customizableEdges27;
            guna2Transition1.SetDecoration(btnGoogleLogin, Guna.UI2.AnimatorNS.DecorationType.None);
            btnGoogleLogin.DisabledState.BorderColor = Color.DarkGray;
            btnGoogleLogin.DisabledState.CustomBorderColor = Color.DarkGray;
            btnGoogleLogin.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnGoogleLogin.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnGoogleLogin.FillColor = Color.Transparent;
            btnGoogleLogin.Font = new Font("Segoe UI", 9F);
            btnGoogleLogin.ForeColor = Color.Black;
            btnGoogleLogin.Image = Properties.Resources.google;
            btnGoogleLogin.Location = new Point(81, 22);
            btnGoogleLogin.Name = "btnGoogleLogin";
            btnGoogleLogin.ShadowDecoration.CustomizableEdges = customizableEdges28;
            btnGoogleLogin.Size = new Size(100, 33);
            btnGoogleLogin.TabIndex = 0;
            btnGoogleLogin.Text = "Google";
            btnGoogleLogin.Click += btnGoogleLogin_Click;
            // 
            // btnLogar
            // 
            btnLogar.BorderRadius = 6;
            btnLogar.CustomizableEdges = customizableEdges29;
            guna2Transition1.SetDecoration(btnLogar, Guna.UI2.AnimatorNS.DecorationType.None);
            btnLogar.DisabledState.BorderColor = Color.DarkGray;
            btnLogar.DisabledState.CustomBorderColor = Color.DarkGray;
            btnLogar.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnLogar.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnLogar.FillColor = Color.FromArgb(255, 128, 255);
            btnLogar.Font = new Font("Segoe UI", 9F);
            btnLogar.ForeColor = Color.White;
            btnLogar.Location = new Point(91, 248);
            btnLogar.Name = "btnLogar";
            btnLogar.ShadowDecoration.CustomizableEdges = customizableEdges30;
            btnLogar.Size = new Size(149, 30);
            btnLogar.TabIndex = 4;
            btnLogar.Text = "Logar";
            btnLogar.Click += btnLogar_Click;
            // 
            // txtSenha
            // 
            txtSenha.CustomizableEdges = customizableEdges31;
            guna2Transition1.SetDecoration(txtSenha, Guna.UI2.AnimatorNS.DecorationType.None);
            txtSenha.DefaultText = "";
            txtSenha.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtSenha.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtSenha.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtSenha.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtSenha.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSenha.Font = new Font("Segoe UI", 9F);
            txtSenha.ForeColor = Color.Black;
            txtSenha.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSenha.Location = new Point(43, 120);
            txtSenha.Name = "txtSenha";
            txtSenha.PlaceholderText = "Senha";
            txtSenha.SelectedText = "";
            txtSenha.ShadowDecoration.CustomizableEdges = customizableEdges32;
            txtSenha.Size = new Size(227, 25);
            txtSenha.TabIndex = 6;
            // 
            // pictureBox1
            // 
            guna2Transition1.SetDecoration(pictureBox1, Guna.UI2.AnimatorNS.DecorationType.None);
            pictureBox1.Image = Properties.Resources.logo_localperfeito;
            pictureBox1.Location = new Point(315, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(251, 91);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // guna2Transition1
            // 
            guna2Transition1.Cursor = null;
            animation4.AnimateOnlyDifferences = true;
            animation4.BlindCoeff = (PointF)resources.GetObject("animation4.BlindCoeff");
            animation4.LeafCoeff = 0F;
            animation4.MaxTime = 1F;
            animation4.MinTime = 0F;
            animation4.MosaicCoeff = (PointF)resources.GetObject("animation4.MosaicCoeff");
            animation4.MosaicShift = (PointF)resources.GetObject("animation4.MosaicShift");
            animation4.MosaicSize = 0;
            animation4.Padding = new Padding(0);
            animation4.RotateCoeff = 0F;
            animation4.RotateLimit = 0F;
            animation4.ScaleCoeff = (PointF)resources.GetObject("animation4.ScaleCoeff");
            animation4.SlideCoeff = (PointF)resources.GetObject("animation4.SlideCoeff");
            animation4.TimeCoeff = 0F;
            animation4.TransparencyCoeff = 0F;
            guna2Transition1.DefaultAnimation = animation4;
            // 
            // guna2Separator3
            // 
            guna2Transition1.SetDecoration(guna2Separator3, Guna.UI2.AnimatorNS.DecorationType.None);
            guna2Separator3.Location = new Point(41, 290);
            guna2Separator3.Name = "guna2Separator3";
            guna2Separator3.Size = new Size(253, 10);
            guna2Separator3.TabIndex = 15;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panel1);
            guna2Transition1.SetDecoration(this, Guna.UI2.AnimatorNS.DecorationType.None);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login";
            FormClosing += Login_FormClosing;
            FormClosed += Login_FormClosed;
            Load += Login_Load;
            panel1.ResumeLayout(false);
            guna2ShadowPanel1.ResumeLayout(false);
            guna2ShadowPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)picmostrarocultar).EndInit();
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel1;
        private Label label3;
        private LinkLabel linkLabel1;
        private Guna.UI2.WinForms.Guna2TextBox txtSenha;
        private Guna.UI2.WinForms.Guna2TextBox txtEmail;
        private Guna.UI2.WinForms.Guna2Button btnLogar;
        private PictureBox pictureBox1;
        private GroupBox groupBox1;
        private Guna.UI2.WinForms.Guna2Button btnGoogleLogin;
        private Guna.UI2.WinForms.Guna2Transition guna2Transition1;
        private PictureBox picmostrarocultar;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator2;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator1;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator3;
    }
}