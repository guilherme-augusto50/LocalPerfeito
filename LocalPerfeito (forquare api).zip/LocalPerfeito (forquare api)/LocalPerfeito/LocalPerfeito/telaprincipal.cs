﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LocalPerfeito
{
    public partial class telaprincipal : Form
    {
        public telaprincipal()
        {
            InitializeComponent();
        }

        /*private Panel CriarPainelRestaurante(restarant r)
        {
            Panel painel = new Panel
            {
                Width = 200,
                Height = 250,
                BorderStyle = BorderStyle.FixedSingle,
                Margin = new Padding(10)
            };

            PictureBox img = new PictureBox
            {
                Width = 180,
                Height = 120,
                SizeMode = PictureBoxSizeMode.StretchImage,
                ImageLocation = r.ImageUrl // <- cuidado: se for null, usar imagem padrão
            };
            painel.Controls.Add(img);
            img.Top = 5;
            img.Left = 10;

            Label lblNome = new Label
            {
                Text = r.Name,
                AutoSize = false,
                Width = 180,
                Top = img.Bottom + 5,
                Left = 10
            };
            painel.Controls.Add(lblNome);

            Label lblCategoria = new Label
            {
                Text = "Categoria: " + r.Categories,
                AutoSize = false,
                Width = 180,
                Top = lblNome.Bottom + 5,
                Left = 10
            };
            painel.Controls.Add(lblCategoria);

            return painel;
        }*/


        private void telaprincipal_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void telaprincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button6_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private async void telaprincipal_Load_1(object sender, EventArgs e)
        {

        }

        private void flowRestaurantes_Paint(object sender, PaintEventArgs e)
        {

        }

        private void toolStripContainer2_TopToolStripPanel_Click(object sender, EventArgs e)
        {

        }

        private void BtnInicio_Click(object sender, EventArgs e)
        {

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private async void btnBuscarLocais_Click(object sender, EventArgs e)
        {
            try
            {
                var restaurantes = await FoursquareApi.GetRestaurantsAsync("-19.9208300", "-43.9377800"); // Exemplo de coordenadas (São Francisco, CA)
                MessageBox.Show($"Foram encontrados {restaurantes.Count} restaurantes.", "Busca Completa", MessageBoxButtons.OK, MessageBoxIcon.Information);

                if (restaurantes.Count == 0)
                {
                    MessageBox.Show("Nenhum restaurante encontrado.", "Busca Completa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                foreach (var restaurante in restaurantes)
                {
                    listBoxRestaurantes.Items.Add(restaurante.Nome);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao buscar locais: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        /*private void MostrarRestaurantesNaTela(List<restarant> restaurantes)
        {
            flpRestaurantes.Controls.Clear(); // limpa antes

            foreach (var r in restaurantes)
            {
                Panel painel = new Panel
                {
                    Width = 300,
                    Height = 100,
                    BorderStyle = BorderStyle.FixedSingle,
                    Margin = new Padding(10)
                };

                PictureBox pic = new PictureBox
                {
                    Width = 80,
                    Height = 80,
                    SizeMode = PictureBoxSizeMode.Zoom,
                    ImageLocation = r.ImageUrl,
                    Left = 10,
                    Top = 10
                };

                Label lblNome = new Label
                {
                    Text = r.Name,
                    Left = 100,
                    Top = 10,
                    Width = 180,
                    Font = new Font("Segoe UI", 10, FontStyle.Bold)
                };

                Label lblEndereco = new Label
                {
                    Text = r.Location,
                    Left = 100,
                    Top = 35,
                    Width = 180
                };

                painel.Controls.Add(pic);
                painel.Controls.Add(lblNome);
                painel.Controls.Add(lblEndereco);

                flpRestaurantes.Controls.Add(painel);
            }
        }*/


        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void guna2ContextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

       

        private void guna2HtmlToolTip1_Popup(object sender, PopupEventArgs e)
        {

        }
    }
}
