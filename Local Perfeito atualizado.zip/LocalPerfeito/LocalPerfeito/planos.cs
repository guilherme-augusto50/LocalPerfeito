﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LocalPerfeito
{
    public partial class planos : Form
    {
        private string fotoUrl;

        public string FotoUrl
        {
            get { return fotoUrl; }
            set { fotoUrl = value; }
        }
        public planos(string fotourl )
        {
            InitializeComponent();
            this.fotoUrl = FotoUrl;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void guna2Separator2_Click(object sender, EventArgs e)
        {

        }

        private void guna2Separator1_Click(object sender, EventArgs e)
        {

        }

        private void guna2Separator3_Click(object sender, EventArgs e)
        {

        }

        private void PIXBtn_Click(object sender, EventArgs e)
        {
            pix pix = new pix(fotoUrl);
            pix.Show();
            this.Hide();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            telaprincipal principal = new telaprincipal(fotoUrl, Name);
            principal.Show();
            this.Hide();
        }

        private void CartaoBtn_Click(object sender, EventArgs e)
        {
            cartao cartao = new cartao(fotoUrl);
            cartao.Show();
            this.Hide();
        }
    }
}
