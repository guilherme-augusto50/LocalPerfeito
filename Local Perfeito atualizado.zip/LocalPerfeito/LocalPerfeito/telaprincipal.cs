﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LocalPerfeito
{
    public partial class telaprincipal : Form
    {
        private string fotoUrl { get; set; }
        private string nome { get; set; }
        public telaprincipal(string fotoUrl, string nome)
        {
            InitializeComponent();
            this.fotoUrl = fotoUrl;
            this.nome = nome;
        }
        private void telaprincipal_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void telaprincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button6_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private async void telaprincipal_Load_1(object sender, EventArgs e)
        {
            panelUsercontrol.Controls.Clear();
            var tela = new USPrincipal(fotoUrl);
            tela.Dock = DockStyle.Fill;

            panelUsercontrol.Controls.Add(tela);
        }


        private void flowRestaurantes_Paint(object sender, PaintEventArgs e)
        {

        }

        private void toolStripContainer2_TopToolStripPanel_Click(object sender, EventArgs e)
        {

        }

        private void BtnInicio_Click(object sender, EventArgs e)
        {

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private async void btnBuscarLocais_Click(object sender, EventArgs e)
        {
        }
        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void guna2ContextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void FP_usuario_Click(object sender, EventArgs e)
        {

        }

        private void panelUsercontrol_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
