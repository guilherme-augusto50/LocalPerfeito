﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LocalPerfeito
{
    public partial class PerfilControl : UserControl
    {
        private string fotoUrl;

        public string FotoUrl
        {
            get { return fotoUrl; }
            set { fotoUrl = value; }
        }

        public PerfilControl(string fotourl)
        {
            InitializeComponent();
            this.FotoUrl = fotourl;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void PerfilControl_Load(object sender, EventArgs e)
        {
            this.Dock = DockStyle.Fill;
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void menuStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void inícioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                var parentForm = this.Parent; // Obtém o formulário pai

                if (parentForm != null)
                {
                    parentForm.Controls.Clear(); // Limpa o que estiver dentro do formulário pai


                    USPrincipal principal = new USPrincipal(FotoUrl); // Cria a instância do UserControl
                    principal.Dock = DockStyle.Fill; // Define o preenchimento do Dock

                    parentForm.Controls.Add(principal); // Adiciona o UserControl ao painel
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível abrir o UserControl do perfil: " + ex.Message);
            }
        }
    }
}
