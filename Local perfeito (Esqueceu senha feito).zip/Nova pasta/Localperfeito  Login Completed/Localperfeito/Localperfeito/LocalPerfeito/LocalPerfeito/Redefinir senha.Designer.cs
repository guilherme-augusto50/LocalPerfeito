﻿namespace LocalPerfeito
{
    partial class Redefinir_senha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            label2 = new Label();
            label1 = new Label();
            Btn_Redefinir = new Guna.UI2.WinForms.Guna2Button();
            txtEmail = new TextBox();
            txtNovaSenha = new TextBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            guna2ShadowPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(211, 193, 255);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(guna2ShadowPanel1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 450);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.logo_localperfeito;
            pictureBox1.Location = new Point(253, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(281, 123);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // guna2ShadowPanel1
            // 
            guna2ShadowPanel1.BackColor = Color.Transparent;
            guna2ShadowPanel1.Controls.Add(txtNovaSenha);
            guna2ShadowPanel1.Controls.Add(label2);
            guna2ShadowPanel1.Controls.Add(label1);
            guna2ShadowPanel1.Controls.Add(Btn_Redefinir);
            guna2ShadowPanel1.Controls.Add(txtEmail);
            guna2ShadowPanel1.FillColor = Color.White;
            guna2ShadowPanel1.Location = new Point(200, 141);
            guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            guna2ShadowPanel1.Radius = 10;
            guna2ShadowPanel1.ShadowColor = Color.Black;
            guna2ShadowPanel1.Size = new Size(404, 252);
            guna2ShadowPanel1.TabIndex = 3;
            guna2ShadowPanel1.Paint += guna2ShadowPanel1_Paint;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft YaHei", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(152, 135, 197);
            label2.Location = new Point(33, 28);
            label2.Name = "label2";
            label2.Size = new Size(188, 28);
            label2.TabIndex = 3;
            label2.Text = "Criar nova senha";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft YaHei", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(33, 67);
            label1.Name = "label1";
            label1.Size = new Size(249, 17);
            label1.TabIndex = 2;
            label1.Text = "Coloque uma senha diferente da anterior";
            // 
            // Btn_Redefinir
            // 
            Btn_Redefinir.BorderRadius = 10;
            Btn_Redefinir.CustomizableEdges = customizableEdges3;
            Btn_Redefinir.DisabledState.BorderColor = Color.DarkGray;
            Btn_Redefinir.DisabledState.CustomBorderColor = Color.DarkGray;
            Btn_Redefinir.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            Btn_Redefinir.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            Btn_Redefinir.FillColor = Color.FromArgb(249, 0, 232);
            Btn_Redefinir.Font = new Font("Segoe UI", 9F);
            Btn_Redefinir.ForeColor = Color.White;
            Btn_Redefinir.Location = new Point(115, 192);
            Btn_Redefinir.Name = "Btn_Redefinir";
            Btn_Redefinir.ShadowDecoration.CustomizableEdges = customizableEdges4;
            Btn_Redefinir.Size = new Size(138, 34);
            Btn_Redefinir.TabIndex = 0;
            Btn_Redefinir.Text = "Redefinir Senha";
            Btn_Redefinir.Click += guna2Button1_Click;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(33, 99);
            txtEmail.Multiline = true;
            txtEmail.Name = "txtEmail";
            txtEmail.PlaceholderText = "E-mail";
            txtEmail.Size = new Size(327, 28);
            txtEmail.TabIndex = 1;
            txtEmail.TextChanged += textBox1_TextChanged;
            // 
            // txtNovaSenha
            // 
            txtNovaSenha.Location = new Point(33, 143);
            txtNovaSenha.Name = "txtNovaSenha";
            txtNovaSenha.PlaceholderText = "Nova Senha";
            txtNovaSenha.Size = new Size(327, 23);
            txtNovaSenha.TabIndex = 4;
            txtNovaSenha.TextChanged += txtNovaSenha_TextChanged;
            // 
            // Redefinir_senha
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panel1);
            Name = "Redefinir_senha";
            Text = "Redefinir_senha";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            guna2ShadowPanel1.ResumeLayout(false);
            guna2ShadowPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Guna.UI2.WinForms.Guna2Button Btn_Redefinir;
        private PictureBox pictureBox1;
        private TextBox txtEmail;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private Label label2;
        private Label label1;
        private TextBox txtNovaSenha;
    }
}