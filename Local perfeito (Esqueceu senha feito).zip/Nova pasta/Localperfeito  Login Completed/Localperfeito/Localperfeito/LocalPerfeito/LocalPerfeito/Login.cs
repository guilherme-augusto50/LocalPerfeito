﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LocalPerfeito
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            txtSenha.UseSystemPasswordChar = true; // Configura o campo de senha para ocultar os caracteres digitados
            picmostrarocultar.Image = Properties.Resources.eye_off; // Define o ícone de olho fechado inicialmente
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            cadastro cadastroForm = new cadastro();
            cadastroForm.Show();
            this.Hide();
        }

        private void btnLogar_Click(object sender, EventArgs e)
        {
            try
            {
                if (!txtEmail.TabStop.Equals("") && !txtSenha.Text.Equals(""))
                {
                    usuarios usuario = new usuarios();
                    usuario.Email = txtEmail.Text;
                    usuario.Senha = txtSenha.Text;

                    if (!usuarios.verificarEmail(usuario.Email))
                    {
                        MessageBox.Show("Email inválido. Por favor, insira um email válido.", "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else if (usuario.Senha.Length < 6 || usuario.Senha.Length == 6)
                    {
                        MessageBox.Show("A senha deve ser maior que 6 caracteres.", "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else
                    {
                        if (usuario.logar())
                        {
                            MessageBox.Show("Login realizado com sucesso!", "Login", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            telaprincipal telaprincipalForm = new telaprincipal();
                            telaprincipalForm.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Email ou senha incorretos.", "Erro de Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao tentar logar: " + ex.Message, "Erro - Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            txtSenha.UseSystemPasswordChar = !txtSenha.UseSystemPasswordChar;

            if (txtSenha.UseSystemPasswordChar)
            {
                picmostrarocultar.Image = Properties.Resources.eye_off; // Ícone de olho fechado
            }
            else
            {
                picmostrarocultar.Image = Properties.Resources.eye_icon_png_13; // Ícone de olho aberto
            }
        }

        private async void btnGoogleLogin_Click(object sender, EventArgs e)
        {
            // Apaga token salvo para forçar o login a cada vez
            string tokenPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "GoogleOAuthLogin"
            );

            if (Directory.Exists(tokenPath))
            {
                Directory.Delete(tokenPath, true);
            }

            var clientSecrets = new Google.Apis.Auth.OAuth2.ClientSecrets
            {
                ClientId = "650460808991-bobojgm5jo2oqruk0sjhr5vtpsop0h2v.apps.googleusercontent.com",
                ClientSecret = "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"
            };

            var scopes = new[] { "email", "profile" };

            var credential = await Google.Apis.Auth.OAuth2.GoogleWebAuthorizationBroker.AuthorizeAsync(
                clientSecrets,
                scopes,
                "usuario_local", // este nome é irrelevante já que apagamos o token antes
                CancellationToken.None,
                new Google.Apis.Util.Store.FileDataStore("GoogleOAuthLogin")
            );

            var payload = await Google.Apis.Auth.GoogleJsonWebSignature.ValidateAsync(credential.Token.IdToken);

            string nome = payload.Name;
            string email = payload.Email;
            string senha = "GOOGLE_OAUTH";

            // Conectar ao banco
            string connStr = "server=localhost;user=root;database=localperfeito;password=;";
            using (var conn = new MySqlConnection(connStr))
            {
                await conn.OpenAsync();

                string checkQuery = "SELECT COUNT(*) FROM usuarios WHERE email = @Email";
                using (var checkCmd = new MySqlCommand(checkQuery, conn))
                {
                    checkCmd.Parameters.AddWithValue("@Email", email);
                    var result = Convert.ToInt32(await checkCmd.ExecuteScalarAsync());

                    if (result == 0)
                    {
                        string insertQuery = "INSERT INTO usuarios (nome, email, senha) VALUES (@Nome, @Email, @Senha)";
                        using (var insertCmd = new MySqlCommand(insertQuery, conn))
                        {
                            insertCmd.Parameters.AddWithValue("@Nome", nome);
                            insertCmd.Parameters.AddWithValue("@Email", email);
                            insertCmd.Parameters.AddWithValue("@Senha", senha);
                            await insertCmd.ExecuteNonQueryAsync();
                        }
                    }
                }
            }

            MessageBox.Show($"Login Google feito com sucesso!\n\nNome: {nome}\nEmail: {email}");

            telaprincipal telaprincipal = new telaprincipal();
            telaprincipal.Show();
            this.Hide();

        }

        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
