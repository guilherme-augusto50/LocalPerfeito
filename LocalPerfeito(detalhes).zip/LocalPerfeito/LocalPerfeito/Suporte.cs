﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LocalPerfeito
{
    public partial class Suporte : UserControl
    {
        private string idusuario;
        private string nomeusuario;
        private string fotoUrl;


        public Suporte(string idusuario, string nomeusuario, string fotoUrl)
        {
            InitializeComponent();
            this.idusuario = idusuario;
            this.nomeusuario = nomeusuario;
            this.fotoUrl = fotoUrl;
        }

        private void Suporte_Load(object sender, EventArgs e)
        {
            Dock = DockStyle.Fill; // Faz ocupar todo o espaço do UserControl
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {

        }

        private void inícioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                var parentForm = this.Parent; // Obtém o formulário pai

                if (parentForm != null)
                {
                    parentForm.Controls.Clear(); // Limpa o que estiver dentro do formulário pai


                    USPrincipal principal = new USPrincipal(fotoUrl, nomeusuario, idusuario); // Cria a instância do UserControl
                    principal.Dock = DockStyle.Fill; // Define o preenchimento do Dock

                    parentForm.Controls.Add(principal); // Adiciona o UserControl ao painel
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível abrir o UserControl do perfil: " + ex.Message);
            }
        }
    }
}
