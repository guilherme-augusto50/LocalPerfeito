﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System.Data;

namespace LocalPerfeito
{
    public class locais
    {
        public void SalvarLocal(Restaurante restaurante, int categoriaId, string restauranteId)
        {
            try
            {
                using (var conection = new ConexaoDb().Conectar())
                {
                    conection.Open();
                    var query = "INSERT INTO locais (id, nome, endereco, contato, categoria, avaliacao, descricao) " +
                                "VALUES (@id, @nome, @endereco, @contato, @categoria, @avaliacao, @descricao)";

                    using (var command = new MySqlCommand(query, conection))
                    {
                        command.Parameters.AddWithValue("@id", restaurante.id);
                        command.Parameters.AddWithValue("@nome", restaurante.Nome);
                        command.Parameters.AddWithValue("@endereco", restaurante.Endereco);
                        command.Parameters.AddWithValue("@contato", restaurante.Contato);
                        command.Parameters.AddWithValue("@categoria", categoriaId);
                        command.Parameters.AddWithValue("@avaliacao", restaurante.Avaliacao);
                        command.Parameters.AddWithValue("@descricao", restaurante.Descricao);
                        command.ExecuteNonQuery();

                        MessageBox.Show("Local salvo com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao salvar local: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void MarcarLocal(int idusuario, int idlocal)
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoDb().Conectar())
                {
                    conexao.Open();
                    string query = "SELECT nome, endereco, categoria, avaliacao FROM locais";
                    using (MySqlCommand command = new MySqlCommand(query, conexao))
                    {
                        using (var da = new MySqlDataAdapter(command))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                        }
                    }
                }
                MessageBox.Show("Local marcado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao marcar local: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
