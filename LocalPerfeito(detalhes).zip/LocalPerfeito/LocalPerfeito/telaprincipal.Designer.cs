﻿namespace LocalPerfeito
{
    partial class telaprincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(telaprincipal));
            panel1 = new Panel();
            panelUsercontrol = new Panel();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Location = new Point(701, 165);
            panel1.Name = "panel1";
            panel1.Size = new Size(477, 237);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // panelUsercontrol
            // 
            panelUsercontrol.Dock = DockStyle.Fill;
            panelUsercontrol.Location = new Point(0, 0);
            panelUsercontrol.Name = "panelUsercontrol";
            panelUsercontrol.Size = new Size(848, 450);
            panelUsercontrol.TabIndex = 0;
            panelUsercontrol.Paint += panelUsercontrol_Paint;
            // 
            // telaprincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(848, 450);
            Controls.Add(panelUsercontrol);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "telaprincipal";
            StartPosition = FormStartPosition.CenterScreen;
            WindowState = FormWindowState.Maximized;
            FormClosing += telaprincipal_FormClosing;
            FormClosed += telaprincipal_FormClosed;
            Load += telaprincipal_Load_1;
            ResumeLayout(false);
        }

        #endregion
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Panel panel1;
        private Panel panelUsercontrol;
    }
}