﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LocalPerfeito
{
    public partial class Endereço : Form
    {
        private string email;
        public Endereço(string email)
        {
            InitializeComponent();
            this.email = email;
        }

        private void Endereço_Load(object sender, EventArgs e)
        {

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            try
            {
                string endereco = txtEndereco.Text.Trim();
                if (string.IsNullOrEmpty(endereco))
                {
                    MessageBox.Show("Por favor, insira um endereço válido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    usuarios usuario = new usuarios();
                    usuario.Endereco = endereco;
                    usuario.Email = this.email; // Atribui o email do usuário atual

                    usuario.verificarEndereço(); // Chama o método para atualizar o endereço do usuário


                    this.DialogResult = DialogResult.OK; // Define o resultado do diálogo como OK
                    this.Close(); // Fecha o formulário de endereço
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao salvar o endereço: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
    }
}
