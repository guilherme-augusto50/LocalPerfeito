﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LocalPerfeito
{
    public partial class DetalhesRestaurantes : UserControl
    {
        private string fotoUrl;
        private Restaurante restaurante;
        public DetalhesRestaurantes(Restaurante restauranteSelecionado)
        {
            InitializeComponent();
            this.restaurante = restauranteSelecionado;
            ExibirInformaçoes();
        }
        private void ExibirInformaçoes()
        {
            lblNome.Text = restaurante.Nome;
            lblEndereco.Text = "Endereço:" + restaurante.Endereco;
            lblContato.Text = "Contato: " + restaurante.Contato;
            lblCategoria.Text = "Categoria: " + restaurante.Categoria;
            lblRating.Text = restaurante.Avaliacao + "estrelas";


        }

        private void btnAgendar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Agendamento realizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void inícioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panelDetalhes.Controls.Clear();
            telaprincipal principal = new telaprincipal(fotoUrl);
            principal.Dock = DockStyle.Fill;

            panelDetalhes.Controls.Add(principal);
        }
    }
}
