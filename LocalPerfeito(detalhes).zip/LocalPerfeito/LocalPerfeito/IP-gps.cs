﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace LocalPerfeito
{
    public class IP_gps
    {
        public static async Task<(string latitude, string longitude)> ObterCoordenadas() {
            using (HttpClient client = new HttpClient())
            {
                string url = "https://ipinfo.io/json";
                var response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return (null, null);
                }
                string json = await response.Content.ReadAsStringAsync();
                JObject data = JObject.Parse(json);

               string loc = data["loc"]?.ToString();
                if (loc != null)
                {
                    string[] partes = loc.Split(',');
                    if (partes.Length == 2)
                    {
                        string lat = partes[0].Trim();
                        string lon = partes[1].Trim();
                        return (lat, lon);
                    }
                }

                return (null,null);
            }
        }
    }
}
