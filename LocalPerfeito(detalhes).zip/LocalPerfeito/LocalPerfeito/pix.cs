﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LocalPerfeito
{
    public partial class pix : Form
    {
        private string fotoUrl;
        private string nomeusuario;
        private string idusuario;

        public string FotoUrl
        {
            get { return fotoUrl; }
            set { fotoUrl = value; }
        }
        public pix(string fotos)
        {
            InitializeComponent();
            this.FotoUrl = fotos;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            planos planos = new planos(fotoUrl, nomeusuario, idusuario);
            planos.Show();
            this.Hide();

        }
    }
}
