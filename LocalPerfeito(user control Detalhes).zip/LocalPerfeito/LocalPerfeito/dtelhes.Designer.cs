﻿namespace LocalPerfeito
{
    partial class dtelhes
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            pictureBox4 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            textBox1 = new TextBox();
            menuStrip = new MenuStrip();
            inícioToolStripMenuItem = new ToolStripMenuItem();
            variedadesToolStripMenuItem = new ToolStripMenuItem();
            favoritosToolStripMenuItem = new ToolStripMenuItem();
            perfilToolStripMenuItem = new ToolStripMenuItem();
            suporteToolStripMenuItem = new ToolStripMenuItem();
            lblNome = new Label();
            lblCategoria = new Label();
            lblEndereco = new Label();
            lblAvaliaçao = new Label();
            lblContato = new Label();
            richTextBox1 = new RichTextBox();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            menuStrip.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.logo_localperfeito;
            pictureBox4.Location = new Point(16, 0);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(166, 85);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 12;
            pictureBox4.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(198, 31);
            label1.Name = "label1";
            label1.Size = new Size(108, 15);
            label1.TabIndex = 18;
            label1.Text = "Locais ao seu redor";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Impact", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(198, 8);
            label2.Name = "label2";
            label2.Size = new Size(121, 23);
            label2.TabIndex = 16;
            label2.Text = "RESTAURANTES";
            label2.Click += label2_Click;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Top;
            textBox1.Location = new Point(404, 12);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Pesquisa";
            textBox1.Size = new Size(284, 23);
            textBox1.TabIndex = 13;
            // 
            // menuStrip
            // 
            menuStrip.Dock = DockStyle.None;
            menuStrip.GripStyle = ToolStripGripStyle.Visible;
            menuStrip.Items.AddRange(new ToolStripItem[] { inícioToolStripMenuItem, variedadesToolStripMenuItem, favoritosToolStripMenuItem, perfilToolStripMenuItem, suporteToolStripMenuItem });
            menuStrip.LayoutStyle = ToolStripLayoutStyle.VerticalStackWithOverflow;
            menuStrip.Location = new Point(3, 91);
            menuStrip.Name = "menuStrip";
            menuStrip.Padding = new Padding(5, 5, 8, 10);
            menuStrip.RenderMode = ToolStripRenderMode.Professional;
            menuStrip.Size = new Size(98, 401);
            menuStrip.TabIndex = 19;
            // 
            // inícioToolStripMenuItem
            // 
            inícioToolStripMenuItem.Checked = true;
            inícioToolStripMenuItem.CheckState = CheckState.Checked;
            inícioToolStripMenuItem.Image = Properties.Resources.grid_web_7__1_;
            inícioToolStripMenuItem.Name = "inícioToolStripMenuItem";
            inícioToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            inícioToolStripMenuItem.Size = new Size(84, 75);
            inícioToolStripMenuItem.Text = "Início";
            // 
            // variedadesToolStripMenuItem
            // 
            variedadesToolStripMenuItem.Image = Properties.Resources.store;
            variedadesToolStripMenuItem.Name = "variedadesToolStripMenuItem";
            variedadesToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            variedadesToolStripMenuItem.Size = new Size(84, 75);
            variedadesToolStripMenuItem.Text = "Detalhes";
            // 
            // favoritosToolStripMenuItem
            // 
            favoritosToolStripMenuItem.Image = Properties.Resources.star;
            favoritosToolStripMenuItem.Name = "favoritosToolStripMenuItem";
            favoritosToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            favoritosToolStripMenuItem.Size = new Size(84, 75);
            favoritosToolStripMenuItem.Text = "Favoritos";
            // 
            // perfilToolStripMenuItem
            // 
            perfilToolStripMenuItem.Image = Properties.Resources.users_group_alt__1_;
            perfilToolStripMenuItem.Name = "perfilToolStripMenuItem";
            perfilToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            perfilToolStripMenuItem.Size = new Size(84, 75);
            perfilToolStripMenuItem.Text = "Perfil";
            // 
            // suporteToolStripMenuItem
            // 
            suporteToolStripMenuItem.Image = Properties.Resources.lightbulb;
            suporteToolStripMenuItem.Name = "suporteToolStripMenuItem";
            suporteToolStripMenuItem.Padding = new Padding(5, 5, 5, 50);
            suporteToolStripMenuItem.Size = new Size(84, 75);
            suporteToolStripMenuItem.Text = "Suporte";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(268, 123);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(40, 15);
            lblNome.TabIndex = 20;
            lblNome.Text = "Nome";
            // 
            // lblCategoria
            // 
            lblCategoria.AutoSize = true;
            lblCategoria.Location = new Point(268, 156);
            lblCategoria.Name = "lblCategoria";
            lblCategoria.Size = new Size(58, 15);
            lblCategoria.TabIndex = 21;
            lblCategoria.Text = "Categoria";
            // 
            // lblEndereco
            // 
            lblEndereco.AutoSize = true;
            lblEndereco.Location = new Point(383, 123);
            lblEndereco.Name = "lblEndereco";
            lblEndereco.Size = new Size(56, 15);
            lblEndereco.TabIndex = 22;
            lblEndereco.Text = "Endereço";
            // 
            // lblAvaliaçao
            // 
            lblAvaliaçao.AutoSize = true;
            lblAvaliaçao.Location = new Point(383, 156);
            lblAvaliaçao.Name = "lblAvaliaçao";
            lblAvaliaçao.Size = new Size(58, 15);
            lblAvaliaçao.TabIndex = 23;
            lblAvaliaçao.Text = "Avaliaçao";
            // 
            // lblContato
            // 
            lblContato.AutoSize = true;
            lblContato.Location = new Point(321, 189);
            lblContato.Name = "lblContato";
            lblContato.Size = new Size(50, 15);
            lblContato.TabIndex = 24;
            lblContato.Text = "Contato";
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(259, 226);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(223, 73);
            richTextBox1.TabIndex = 25;
            richTextBox1.Text = "";
            // 
            // guna2Button1
            // 
            guna2Button1.CustomizableEdges = customizableEdges3;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.Font = new Font("Segoe UI", 9F);
            guna2Button1.ForeColor = Color.White;
            guna2Button1.Location = new Point(166, 388);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2Button1.Size = new Size(180, 27);
            guna2Button1.TabIndex = 26;
            guna2Button1.Text = "guna2Button1";
            // 
            // dtelhes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(guna2Button1);
            Controls.Add(richTextBox1);
            Controls.Add(lblContato);
            Controls.Add(lblAvaliaçao);
            Controls.Add(lblEndereco);
            Controls.Add(lblCategoria);
            Controls.Add(lblNome);
            Controls.Add(pictureBox4);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(menuStrip);
            Name = "dtelhes";
            Size = new Size(800, 450);
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            menuStrip.ResumeLayout(false);
            menuStrip.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox4;
        private Label label1;
        private Label label2;
        private TextBox textBox1;
        private MenuStrip menuStrip;
        private ToolStripMenuItem inícioToolStripMenuItem;
        private ToolStripMenuItem variedadesToolStripMenuItem;
        private ToolStripMenuItem favoritosToolStripMenuItem;
        private ToolStripMenuItem perfilToolStripMenuItem;
        private ToolStripMenuItem suporteToolStripMenuItem;
        private Label lblNome;
        private Label lblCategoria;
        private Label lblEndereco;
        private Label lblAvaliaçao;
        private Label lblContato;
        private RichTextBox richTextBox1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
    }
}
