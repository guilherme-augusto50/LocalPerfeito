﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LocalPerfeito
{
    public partial class dtelhes : UserControl
    {
        public dtelhes(Restaurante restaurante)
        {
            InitializeComponent();

            lblNome.Text = restaurante.Nome;
            lblEndereco.Text = "Endereço:" + restaurante.Endereco;
            lblCategoria.Text = "Categoria: " + restaurante.Categoria;
            lblAvaliaçao.Text = "Avaliação: " + restaurante.Avaliacao;
            lblContato.Text = "Contato: " + restaurante.Contato;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }
    }
}
