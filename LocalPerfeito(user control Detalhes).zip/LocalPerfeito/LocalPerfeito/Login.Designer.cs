﻿namespace LocalPerfeito
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.AnimatorNS.Animation animation1 = new Guna.UI2.AnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            panel1 = new Panel();
            guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            linkEsqueceuSenha = new LinkLabel();
            guna2Separator3 = new Guna.UI2.WinForms.Guna2Separator();
            label1 = new Label();
            guna2Separator1 = new Guna.UI2.WinForms.Guna2Separator();
            guna2Separator2 = new Guna.UI2.WinForms.Guna2Separator();
            txtEmail = new Guna.UI2.WinForms.Guna2TextBox();
            linkLabel1 = new LinkLabel();
            picmostrarocultar = new PictureBox();
            label3 = new Label();
            groupBox1 = new GroupBox();
            btnGoogleLogin = new Guna.UI2.WinForms.Guna2Button();
            btnLogar = new Guna.UI2.WinForms.Guna2Button();
            txtSenha = new Guna.UI2.WinForms.Guna2TextBox();
            pictureBox1 = new PictureBox();
            guna2Transition1 = new Guna.UI2.WinForms.Guna2Transition();
            panel1.SuspendLayout();
            guna2ShadowPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picmostrarocultar).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(211, 193, 252);
            panel1.Controls.Add(guna2ShadowPanel1);
            panel1.Controls.Add(pictureBox1);
            guna2Transition1.SetDecoration(panel1, Guna.UI2.AnimatorNS.DecorationType.None);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 450);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // guna2ShadowPanel1
            // 
            guna2ShadowPanel1.BackColor = Color.Transparent;
            guna2ShadowPanel1.Controls.Add(linkEsqueceuSenha);
            guna2ShadowPanel1.Controls.Add(guna2Separator3);
            guna2ShadowPanel1.Controls.Add(label1);
            guna2ShadowPanel1.Controls.Add(guna2Separator1);
            guna2ShadowPanel1.Controls.Add(guna2Separator2);
            guna2ShadowPanel1.Controls.Add(txtEmail);
            guna2ShadowPanel1.Controls.Add(linkLabel1);
            guna2ShadowPanel1.Controls.Add(picmostrarocultar);
            guna2ShadowPanel1.Controls.Add(label3);
            guna2ShadowPanel1.Controls.Add(groupBox1);
            guna2ShadowPanel1.Controls.Add(btnLogar);
            guna2ShadowPanel1.Controls.Add(txtSenha);
            guna2Transition1.SetDecoration(guna2ShadowPanel1, Guna.UI2.AnimatorNS.DecorationType.None);
            guna2ShadowPanel1.FillColor = Color.White;
            guna2ShadowPanel1.Location = new Point(267, 100);
            guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            guna2ShadowPanel1.Radius = 6;
            guna2ShadowPanel1.ShadowColor = Color.Black;
            guna2ShadowPanel1.Size = new Size(324, 338);
            guna2ShadowPanel1.TabIndex = 12;
            // 
            // linkEsqueceuSenha
            // 
            linkEsqueceuSenha.AutoSize = true;
            guna2Transition1.SetDecoration(linkEsqueceuSenha, Guna.UI2.AnimatorNS.DecorationType.None);
            linkEsqueceuSenha.LinkColor = Color.Fuchsia;
            linkEsqueceuSenha.Location = new Point(206, 148);
            linkEsqueceuSenha.Name = "linkEsqueceuSenha";
            linkEsqueceuSenha.Size = new Size(92, 15);
            linkEsqueceuSenha.TabIndex = 16;
            linkEsqueceuSenha.TabStop = true;
            linkEsqueceuSenha.Text = "Esqueceu Senha";
            linkEsqueceuSenha.LinkClicked += linkEsqueceuSenha_LinkClicked;
            // 
            // guna2Separator3
            // 
            guna2Transition1.SetDecoration(guna2Separator3, Guna.UI2.AnimatorNS.DecorationType.None);
            guna2Separator3.Location = new Point(41, 290);
            guna2Separator3.Name = "guna2Separator3";
            guna2Separator3.Size = new Size(253, 10);
            guna2Separator3.TabIndex = 15;
            // 
            // label1
            // 
            label1.AutoSize = true;
            guna2Transition1.SetDecoration(label1, Guna.UI2.AnimatorNS.DecorationType.None);
            label1.Font = new Font("Microsoft YaHei", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Gray;
            label1.Location = new Point(63, 24);
            label1.Name = "label1";
            label1.Size = new Size(192, 26);
            label1.TabIndex = 14;
            label1.Text = "Logar na sua conta";
            // 
            // guna2Separator1
            // 
            guna2Transition1.SetDecoration(guna2Separator1, Guna.UI2.AnimatorNS.DecorationType.None);
            guna2Separator1.Location = new Point(41, 106);
            guna2Separator1.Name = "guna2Separator1";
            guna2Separator1.Size = new Size(253, 10);
            guna2Separator1.TabIndex = 12;
            // 
            // guna2Separator2
            // 
            guna2Transition1.SetDecoration(guna2Separator2, Guna.UI2.AnimatorNS.DecorationType.None);
            guna2Separator2.Location = new Point(43, 163);
            guna2Separator2.Name = "guna2Separator2";
            guna2Separator2.Size = new Size(253, 10);
            guna2Separator2.TabIndex = 13;
            // 
            // txtEmail
            // 
            txtEmail.Cursor = Cursors.IBeam;
            txtEmail.CustomizableEdges = customizableEdges1;
            guna2Transition1.SetDecoration(txtEmail, Guna.UI2.AnimatorNS.DecorationType.None);
            txtEmail.DefaultText = "";
            txtEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Font = new Font("Segoe UI", 9F);
            txtEmail.ForeColor = Color.Black;
            txtEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Location = new Point(45, 77);
            txtEmail.Name = "txtEmail";
            txtEmail.PlaceholderText = "Email";
            txtEmail.SelectedText = "";
            txtEmail.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtEmail.Size = new Size(253, 23);
            txtEmail.TabIndex = 1;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Cursor = Cursors.Hand;
            guna2Transition1.SetDecoration(linkLabel1, Guna.UI2.AnimatorNS.DecorationType.None);
            linkLabel1.LinkColor = Color.Fuchsia;
            linkLabel1.Location = new Point(171, 303);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(84, 15);
            linkLabel1.TabIndex = 5;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Fazer Cadastro";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // picmostrarocultar
            // 
            picmostrarocultar.BackColor = Color.Transparent;
            picmostrarocultar.Cursor = Cursors.Hand;
            guna2Transition1.SetDecoration(picmostrarocultar, Guna.UI2.AnimatorNS.DecorationType.None);
            picmostrarocultar.Image = Properties.Resources.eye_off;
            picmostrarocultar.Location = new Point(276, 120);
            picmostrarocultar.Name = "picmostrarocultar";
            picmostrarocultar.Size = new Size(22, 25);
            picmostrarocultar.SizeMode = PictureBoxSizeMode.StretchImage;
            picmostrarocultar.TabIndex = 10;
            picmostrarocultar.TabStop = false;
            picmostrarocultar.Click += pictureBox2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            guna2Transition1.SetDecoration(label3, Guna.UI2.AnimatorNS.DecorationType.None);
            label3.Location = new Point(63, 303);
            label3.Name = "label3";
            label3.Size = new Size(104, 15);
            label3.TabIndex = 8;
            label3.Text = "não tem cadastro?";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnGoogleLogin);
            guna2Transition1.SetDecoration(groupBox1, Guna.UI2.AnimatorNS.DecorationType.None);
            groupBox1.Location = new Point(43, 179);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(253, 63);
            groupBox1.TabIndex = 9;
            groupBox1.TabStop = false;
            groupBox1.Text = "Entrar com:";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // btnGoogleLogin
            // 
            btnGoogleLogin.Cursor = Cursors.Hand;
            btnGoogleLogin.CustomizableEdges = customizableEdges3;
            guna2Transition1.SetDecoration(btnGoogleLogin, Guna.UI2.AnimatorNS.DecorationType.None);
            btnGoogleLogin.DisabledState.BorderColor = Color.DarkGray;
            btnGoogleLogin.DisabledState.CustomBorderColor = Color.DarkGray;
            btnGoogleLogin.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnGoogleLogin.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnGoogleLogin.FillColor = Color.Transparent;
            btnGoogleLogin.Font = new Font("Segoe UI", 9F);
            btnGoogleLogin.ForeColor = Color.Black;
            btnGoogleLogin.Image = Properties.Resources.google;
            btnGoogleLogin.Location = new Point(81, 22);
            btnGoogleLogin.Name = "btnGoogleLogin";
            btnGoogleLogin.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnGoogleLogin.Size = new Size(100, 33);
            btnGoogleLogin.TabIndex = 3;
            btnGoogleLogin.Text = "Google";
            btnGoogleLogin.Click += btnGoogleLogin_Click;
            // 
            // btnLogar
            // 
            btnLogar.BorderRadius = 6;
            btnLogar.Cursor = Cursors.Hand;
            btnLogar.CustomizableEdges = customizableEdges5;
            guna2Transition1.SetDecoration(btnLogar, Guna.UI2.AnimatorNS.DecorationType.None);
            btnLogar.DisabledState.BorderColor = Color.DarkGray;
            btnLogar.DisabledState.CustomBorderColor = Color.DarkGray;
            btnLogar.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnLogar.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnLogar.FillColor = Color.FromArgb(255, 128, 255);
            btnLogar.Font = new Font("Segoe UI", 9F);
            btnLogar.ForeColor = Color.White;
            btnLogar.Location = new Point(91, 248);
            btnLogar.Name = "btnLogar";
            btnLogar.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnLogar.Size = new Size(151, 36);
            btnLogar.TabIndex = 4;
            btnLogar.Text = "Logar";
            btnLogar.Click += btnLogar_Click;
            // 
            // txtSenha
            // 
            txtSenha.Cursor = Cursors.IBeam;
            txtSenha.CustomizableEdges = customizableEdges7;
            guna2Transition1.SetDecoration(txtSenha, Guna.UI2.AnimatorNS.DecorationType.None);
            txtSenha.DefaultText = "";
            txtSenha.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtSenha.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtSenha.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtSenha.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtSenha.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSenha.Font = new Font("Segoe UI", 9F);
            txtSenha.ForeColor = Color.Black;
            txtSenha.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSenha.Location = new Point(43, 120);
            txtSenha.Name = "txtSenha";
            txtSenha.PlaceholderText = "Senha";
            txtSenha.SelectedText = "";
            txtSenha.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtSenha.Size = new Size(227, 25);
            txtSenha.TabIndex = 2;
            // 
            // pictureBox1
            // 
            guna2Transition1.SetDecoration(pictureBox1, Guna.UI2.AnimatorNS.DecorationType.None);
            pictureBox1.Image = Properties.Resources.logo_localperfeito;
            pictureBox1.Location = new Point(298, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(251, 91);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // guna2Transition1
            // 
            guna2Transition1.Cursor = null;
            animation1.AnimateOnlyDifferences = true;
            animation1.BlindCoeff = (PointF)resources.GetObject("animation1.BlindCoeff");
            animation1.LeafCoeff = 0F;
            animation1.MaxTime = 1F;
            animation1.MinTime = 0F;
            animation1.MosaicCoeff = (PointF)resources.GetObject("animation1.MosaicCoeff");
            animation1.MosaicShift = (PointF)resources.GetObject("animation1.MosaicShift");
            animation1.MosaicSize = 0;
            animation1.Padding = new Padding(0);
            animation1.RotateCoeff = 0F;
            animation1.RotateLimit = 0F;
            animation1.ScaleCoeff = (PointF)resources.GetObject("animation1.ScaleCoeff");
            animation1.SlideCoeff = (PointF)resources.GetObject("animation1.SlideCoeff");
            animation1.TimeCoeff = 0F;
            animation1.TransparencyCoeff = 0F;
            guna2Transition1.DefaultAnimation = animation1;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panel1);
            guna2Transition1.SetDecoration(this, Guna.UI2.AnimatorNS.DecorationType.None);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login";
            FormClosing += Login_FormClosing;
            FormClosed += Login_FormClosed;
            Load += Login_Load;
            panel1.ResumeLayout(false);
            guna2ShadowPanel1.ResumeLayout(false);
            guna2ShadowPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)picmostrarocultar).EndInit();
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel1;
        private Label label3;
        private LinkLabel linkLabel1;
        private Guna.UI2.WinForms.Guna2TextBox txtSenha;
        private Guna.UI2.WinForms.Guna2TextBox txtEmail;
        private Guna.UI2.WinForms.Guna2Button btnLogar;
        private PictureBox pictureBox1;
        private GroupBox groupBox1;
        private Guna.UI2.WinForms.Guna2Button btnGoogleLogin;
        private Guna.UI2.WinForms.Guna2Transition guna2Transition1;
        private PictureBox picmostrarocultar;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator2;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator1;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator3;
        private LinkLabel linkEsqueceuSenha;
    }
}